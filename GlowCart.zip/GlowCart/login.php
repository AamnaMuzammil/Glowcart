<?php
// login.php
session_start();
include('includes/db.php');

$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email_or_username = trim($_POST['email_or_username']);
    $password = trim($_POST['password']);

    // Use prepared statement to avoid SQL Injection
    $sql = "SELECT * FROM Users WHERE (Email = ? OR FullName = ?)";
    $params = array($email_or_username, $email_or_username);
    $stmt = sqlsrv_query($conn, $sql, $params);

    if ($stmt && sqlsrv_has_rows($stmt)) {
        $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);

        // Since you're using plain text password
        if ($password === $row['Password']) {
            $_SESSION['user_id'] = $row['UserID'];
            $_SESSION['user_name'] = $row['FullName'];
            header('Location: index.php');
            exit();
        } else {
            $message = "Invalid email/username or password.";
        }
    } else {
        $message = "Invalid email/username or password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>GlowCart Login</title>

    <!-- FontAwesome & Bootstrap -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />

    <style>
        html, body {
            height: 100%;
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background: url('assets/images/background.jpg') no-repeat center center fixed;
            background-size: cover;
            display: flex;
            flex-direction: column;
        }

        .container {
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .logo {
            text-align: center;
            margin-bottom: 0px;
        }

        .logo img {
            width: 400px;
            height: auto;
        }

        .login-wrapper {
            width: 100%;
            max-width: 500px;
            padding: 25px 40px 30px;
            background: rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(15px);
            border-radius: 20px;
            box-shadow: 0 8px 30px rgba(199, 21, 133, 0.4);
            text-align: center;
            color: #4b0082;
        }

        .login-wrapper h2 {
            font-family: 'Great Vibes', cursive;
            color: rgb(124, 33, 117);
            font-weight: bold;
            margin-bottom: 0px;
        }

        .form-label {
            font-weight: 600;
            color: #a20a55;
        }

        .position-relative {
            position: relative;
        }

        .input-icon {
            position: absolute;
            left: 15px;
            top: 70%;
            transform: translateY(-50%);
            color: #c71585;
            font-size: 18px;
        }

        .form-control {
            border-radius: 25px;
            padding-left: 45px;
            background: rgba(255, 255, 255, 0.7);
            border: 1px solid #c71585;
        }

        .btn-login {
            background: linear-gradient(to right, #c71585, #ff69b4);
            color: white;
            border: none;
            border-radius: 25px;
            width: 100%;
            padding: 10px;
            font-weight: bold;
            font-size: 16px;
            margin-top: 15px;
            transition: transform 0.3s ease, background 0.3s ease;
        }

        .btn-login:hover {
            transform: scale(1.05);
            background: linear-gradient(to right, #ff69b4, #c71585);
        }

        .alert-danger {
            background-color: rgba(255, 99, 132, 0.2);
            border-color: #ff4d6d;
            color: #c71585;
            border-radius: 12px;
            padding: 10px 15px;
            margin-bottom: 15px;
            font-weight: 600;
            text-align: center;
        }

        @media (max-height: 700px) {
            .container {
                justify-content: flex-start;
                margin-top: 20px;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <div class="logo">
        <img src="assets/images/plainlogo.png" alt="GlowCart Logo">
    </div>

    <div class="login-wrapper">
        <h2>Login</h2>
        <?php if (!empty($message)): ?>
            <div class="alert alert-danger"><?php echo $message; ?></div>
        <?php endif; ?>

        <form method="POST" action="login.php" autocomplete="off">
            <div class="mb-3 position-relative">
                <label class="form-label" for="email_or_username">Email or Username</label>
                <i class="fas fa-user input-icon"></i>
                <input type="text" id="email_or_username" class="form-control" name="email_or_username" required autofocus />
            </div>
            <div class="mb-3 position-relative">
                <label class="form-label" for="password">Password</label>
                <i class="fas fa-lock input-icon"></i>
                <input type="password" id="password" class="form-control" name="password" required />
            </div>
            <button type="submit" class="btn btn-login">
                <i class="fas fa-sign-in-alt me-1"></i> Login
            </button>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
