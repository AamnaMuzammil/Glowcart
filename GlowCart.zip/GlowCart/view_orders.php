<?php
session_start();
include('includes/db.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>View Orders - GlowCart</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <style>
        body {
            min-height: 100vh;
            background: url('assets/images/background.jpg') no-repeat center center fixed;
            background-size: cover;
            font-family: 'Segoe UI', sans-serif;
            display: flex;
            flex-direction: column;
        }
        h1, h2 {
            color: rgb(228, 53, 164);
        }
        .container {
            flex: 1;
        }
        .card, table {
            background: rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 12px;
            box-shadow: 0 8px 32px rgba(31, 38, 135, 0.3);
            transition: 0.3s;
        }
        .card:hover, table:hover {
            transform: scale(1.02);
            box-shadow: 0 12px 40px rgba(199, 21, 133, 0.4);
        }
        .card-header {
            background: linear-gradient(135deg, rgba(218,112,214,0.8), rgba(255,105,180,0.8));
            color: white;
        }
        thead {
            background-color: rgba(218, 112, 214, 0.8);
            color: white;
        }
        footer {
            background: rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(10px);
            border-top: 1px solid rgba(255, 255, 255, 0.3);
            padding: 10px 0;
            text-align: center;
            color: white;
            font-size: 14px;
            width: 100%;
        }
        .status-form {
            margin-top: 10px;
        }
    </style>
</head>
<body>

<?php include('includes/header.php'); ?>

<div class="container my-5">

    <h2 class="mb-4 text-center" style="color:white">All Orders</h2>

    <?php if (isset($_SESSION['msg'])): ?>
        <div class="alert alert-info text-center"><?php echo $_SESSION['msg']; unset($_SESSION['msg']); ?></div>
    <?php endif; ?>

    <?php
    $sql = "
    SELECT o.OrderID, o.UserID, o.OrderDate, o.DeliveryAddress, o.PaymentMethod, o.Status,
           oi.OrderItemID, oi.ProductID, oi.Quantity, oi.TotalPrice,
           p.ProductName
    FROM Orders o
    INNER JOIN OrderItems oi ON o.OrderID = oi.OrderID
    INNER JOIN Products p ON oi.ProductID = p.ProductID
    ORDER BY o.OrderDate DESC";

    $stmt = sqlsrv_query($conn, $sql);
    if ($stmt === false) {
        echo "<div class='alert alert-danger'>Error fetching orders: ";
        die(print_r(sqlsrv_errors(), true));
        echo "</div>";
    }

    $orders = [];
    while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        $orderId = $row['OrderID'];
        if (!isset($orders[$orderId])) {
            $orders[$orderId] = [
                'OrderID' => $orderId,
                'UserID' => $row['UserID'],
                'OrderDate' => $row['OrderDate'],
                'DeliveryAddress' => $row['DeliveryAddress'],
                'PaymentMethod' => $row['PaymentMethod'],
                'Status' => $row['Status'],
                'Items' => []
            ];
        }
        $orders[$orderId]['Items'][] = [
            'OrderItemID' => $row['OrderItemID'],
            'ProductID' => $row['ProductID'],
            'ProductName' => $row['ProductName'],
            'Quantity' => $row['Quantity'],
            'TotalPrice' => $row['TotalPrice']
        ];
    }

    if (empty($orders)) {
        echo "<p class='text-center'>No orders found.</p>";
    } else {
        foreach ($orders as $order) {
            echo "<div class='card mb-4'>";
            echo "<div class='card-header'>";
            echo "<strong>Order #{$order['OrderID']}</strong> - Placed on: " . $order['OrderDate']->format('Y-m-d H:i') . "<br>";
            echo "User ID: {$order['UserID']} | Status: <strong>{$order['Status']}</strong><br>";
            echo "Delivery Address: " . htmlspecialchars($order['DeliveryAddress']) . "<br>";
            echo "Payment Method: {$order['PaymentMethod']}";

            // Order status update form
            echo "<form method='POST' action='update_status.php' class='status-form'>";
            echo "<input type='hidden' name='order_id' value='{$order['OrderID']}'>";
            echo "<div class='d-flex align-items-center gap-2 mt-2'>";
            echo "<select name='status' class='form-select form-select-sm w-auto'>";
            $options = ['Pending', 'Shipped', 'Delivered', 'Cancelled'];
            foreach ($options as $statusOption) {
                $selected = ($order['Status'] === $statusOption) ? 'selected' : '';
                echo "<option value='$statusOption' $selected>$statusOption</option>";
            }
            echo "</select>";
            echo "<button type='submit' class='btn btn-sm btn-light'>Update</button>";
            echo "</div></form>";

            echo "</div><div class='card-body p-0'>";
            echo "<table class='table table-striped mb-0'>";
            echo "<thead><tr><th>Product</th><th>Quantity</th><th>Total Price</th></tr></thead><tbody>";
            foreach ($order['Items'] as $item) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($item['ProductName']) . "</td>";
                echo "<td>{$item['Quantity']}</td>";
                echo "<td>Rs. " . number_format($item['TotalPrice'], 2) . "</td>";
                echo "</tr>";
            }
            echo "</tbody></table>";
            echo "</div></div>";
        }
    }
    ?>
</div>

<footer>
    <?php include('includes/footer.php'); ?>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
