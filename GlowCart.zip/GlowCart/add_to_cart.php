<?php
include('includes/db.php');
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

if (isset($_GET['product_id'])) {
    $productID = $_GET['product_id'];
    $userID = $_SESSION['user_id'];

    // Check if item already in cart
    $checkSql = "SELECT * FROM carttwo WHERE UserID = ? AND ProductID = ?";
    $checkParams = array($userID, $productID);
    $checkStmt = sqlsrv_query($conn, $checkSql, $checkParams);

    if (sqlsrv_has_rows($checkStmt)) {
        // Update quantity
        $updateSql = "UPDATE carttwo SET Quantity = Quantity + 1 WHERE UserID = ? AND ProductID = ?";
        sqlsrv_query($conn, $updateSql, $checkParams);
    } else {
        // Insert new
        $insertSql = "INSERT INTO carttwo (UserID, ProductID, Quantity) VALUES (?, ?, 1)";
        sqlsrv_query($conn, $insertSql, array($userID, $productID));
    }
}

header("Location: cart.php");
?>
