<?php
// Start the session
session_start();

// Destroy all session variables
$_SESSION = [];
session_unset();
session_destroy();

// Redirect the user to the homepage (or login page if you prefer)
header("Location: login.php");
exit();
