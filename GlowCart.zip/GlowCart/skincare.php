<?php
session_start();
include('includes/db.php');
include('includes/header.php');

$userID = $_SESSION['user_id'] ?? null;

if (!$userID) {
    die("<p class='text-center text-danger mt-5'>Please login first.</p>");
}

// Fetch user skin preferences securely
$userQuery = "SELECT SkinType, SkinTone FROM Users WHERE UserID = ?";
$userStmt = sqlsrv_prepare($conn, $userQuery, [$userID]);
if (!$userStmt) {
    die("<p class='text-center text-danger mt-5'>Error preparing user query.</p>");
}
if (!sqlsrv_execute($userStmt)) {
    die("<p class='text-center text-danger mt-5'>Error executing user query.</p>");
}

$userSkinType = null;
$userSkinTone = null;

if ($userRow = sqlsrv_fetch_array($userStmt, SQLSRV_FETCH_ASSOC)) {
    $userSkinType = $userRow['SkinType'];
    $userSkinTone = $userRow['SkinTone'];
} else {
    die("<p class='text-center text-danger mt-5'>User not found.</p>");
}

if (!$userSkinTone || !$userSkinType) {
    die("<p class='text-center text-danger mt-5'>Please set your skin type and skin tone preferences in your user dashboard first.</p>");
}

// Build product query with filters
$sql = "SELECT * FROM Products WHERE InStock = 1 AND Category = 'Skincare'";

$conditions = [];
$params = [];

if ($userSkinTone) {
    $conditions[] = "SkinTone = ?";
    $params[] = $userSkinTone;
}
if ($userSkinType) {
    $conditions[] = "SkinType = ?";
    $params[] = $userSkinType;
}

if (count($conditions) > 0) {
    $sql .= " AND " . implode(" AND ", $conditions);
}

$stmt = sqlsrv_prepare($conn, $sql, $params);
if (!$stmt) {
    die("<p class='text-center text-danger mt-5'>Error preparing products query.</p>");
}
if (!sqlsrv_execute($stmt)) {
    die("<p class='text-center text-danger mt-5'>Error executing products query.</p>");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>GlowCart - Skin Care Recommendations</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet" />

   <style>
    @import url('https://fonts.googleapis.com/css2?family=Lobster&family=Poppins:wght@400;600;700&display=swap');

    body {
    background: url('assets/images/background.jpg') no-repeat center center fixed;
    background-size: cover;
    font-family: 'Segoe UI', sans-serif;
}

.card {
    background: rgba(255, 255, 255, 0.12);
    border: 1px solid #ffffff30;
    backdrop-filter: blur(14px);
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.3);
    color: #ffffff;
    transition: transform 0.3s;
    display: flex;
    flex-direction: column;
    height: 480px;
    border-radius: 12px;
}

.card:hover {
    transform: translateY(-5px);
}

.card-img-top {
    height: 180px;
    object-fit: contain;
    padding: 10px;
    background: #fff;
    border-top-left-radius: 0.25rem;
    border-top-right-radius: 0.25rem;
    cursor: pointer;
    transition: transform 0.3s ease;
}

.card-img-top:hover {
    transform: scale(1.05);
}

.card-body {
    flex: 1 1 auto;
    display: flex;
    flex-direction: column;
    padding: 15px;
    background-color: transparent;
}

.card-title {
    font-family: 'Playfair Display', serif;
    font-weight: 700;
    color:rgb(163, 88, 113);
    font-size: 1.4rem;
    text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.6);
    margin-bottom: 8px;
}

.card-description {
    font-family: 'Open Sans', sans-serif;
    font-size: 1rem;
    color: #F8F8FF;
    line-height: 1.5;
    font-weight: 400;
    flex-grow: 1;
    margin-bottom: 10px;
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
}

.category-text {
    font-family: 'Nunito Sans', sans-serif;
    font-size: 0.85rem;
    font-style: italic;
    color: #FFC0CB;
    margin-bottom: 6px;
}

.card-price {
    font-family: 'Montserrat', sans-serif;
    font-size: 1.1rem;
    color: #FF4D4D;
    font-weight: 600;
    margin-bottom: 6px;
}

.card-stock.in-stock {
    font-family: 'Open Sans', sans-serif;
    color: #00FF7F;
    font-size: 0.95rem;
    font-weight: 500;
    margin-bottom: 12px;
}

.card-stock.out-stock {
    color: #a80000;
    font-size: 0.95rem;
    font-weight: 500;
    margin-bottom: 12px;
}
.card-brand {
            font-size: 19px;
            color:rgb(0, 0, 0);
            font-weight: bold;
            font-family: 'Open Sans', sans-serif;
        }
.btn {
    border-radius: 25px;
    font-weight: 600;
    transition: background-color 0.3s ease;
    font-family: 'Poppins', sans-serif;
    background-color: #FF69B4;
    color: white;
    padding: 10px 20px;
    border: none;
}

.btn:hover {
    background-color: #FF1493 !important;
}

.slider {
    width: 100%;
    overflow: hidden;
    margin: 20px auto;
    border-radius: 10px;
}

.slider-track {
    display: flex;
    animation: scroll 15s linear infinite;
}

.slider-track img {
    width: 100%;
    height: 300px;
    object-fit: cover;
}

@keyframes scroll {
    0% { transform: translateX(0); }
    100% { transform: translateX(-100%); }
}

.filter-buttons {
    text-align: center;
    margin-bottom: 20px;
}

.filter-buttons button {
    background-color: #ff69b4;
    color: white;
    margin: 5px;
    border: none;
    padding: 10px 20px;
    border-radius: 20px;
    transition: 0.3s;
    cursor: pointer;
    font-weight: 600;
    font-family: 'Segoe UI', sans-serif;
}

.filter-buttons button:hover {
    background-color: #c71585;
}
</style>

</head>
<body>
<div class="slider">
    <div class="slider-track">
        <img src="assets/images/ssli (4).jpg" alt="Slide 1">
        <img src="assets/images/ssli (2).jpg" alt="Slide 2">
        <img src="assets/images/ssli (3).jpg" alt="Slide 3">
        <img src="assets/images/ssli (4).jpg" alt="Slide 1">
        <img src="assets/images/ssli (1).jpg" alt="Slide 2">
        <img src="assets/images/ssli (2).jpg" alt="Slide 3">
        <img src="assets/images/ssli (3).jpg" alt="Slide 3">
        <img src="assets/images/ssli (4).jpg" alt="Slide 3">


    </div>
</div>

<!-- ✅ New Buttons for Category Navigation -->
<div class="filter-buttons text-center mt-3 mb-4">
    <a href="haircare.php" class="btn">Haircare</a>
    <a href="makeup.php" class="btn">Makeup</a>
</div>

<div class="container content-wrapper">
    <h2 class="text-center mb-4" style="color:white">Skin Care Products Recommended for You</h2>
    <div class="row">
        <?php
        $hasResults = false;
        while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
            $hasResults = true;
            $productID = $row['ProductID'];
            $productName = htmlspecialchars($row['ProductName']);
            $price = number_format((float)$row['Price'], 2);
            $brand = htmlspecialchars($row['BrandName'] ?? 'N/A');
            $description = htmlspecialchars($row['Description'] ?? '');
            $image = !empty($row['ImageURL']) ? $row['ImageURL'] . '?w=400&h=400&fit=crop&auto=format' : 'assets/images/default.jpg';

        ?>
        <div class="col-md-4 mb-4" data-aos="fade-up">
            <div class="card shadow-sm h-100">
               <img src="<?php echo $image; ?>" class="card-img-top" alt="<?php echo $productName; ?>" 
     style="height: 200px; object-fit: contain; padding: 10px; background: #fff; border-top-left-radius: 15px; border-top-right-radius: 15px;">

                <div class="card-body">
                    <h5 class="card-title"><?php echo $productName; ?></h5>
                    <p class="card-brand">Brand: <?php echo $brand; ?></p>
                    <p class="card-description"><?php echo $description; ?></p>
                    <p class="card-text font-weight-bold">$<?php echo $price; ?></p>
                    <a href="add_to_cart.php?product_id=<?php echo $productID; ?>" class="btn btn-custom">Add to Cart</a>
                </div>
            </div>
        </div>
        <?php
        }
        if (!$hasResults) {
            echo "<p class='text-white text-center'>No makeup products found matching your preferences.</p>";
        }
        ?>
    </div>
</div>

<?php include('includes/footer.php'); ?>

<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
<script>
    AOS.init();
</script>
</body>
</html>
