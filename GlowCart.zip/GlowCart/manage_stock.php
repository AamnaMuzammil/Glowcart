<?php
session_start();
include('includes/db.php');

// Simple admin check (adjust as needed)
if (!isset($_SESSION['admin'])) {
    header('Location: admin_login.php');
    exit();
}

// Handle toggle stock status request
if (isset($_POST['toggle_stock']) && isset($_POST['product_id'])) {
    $productID = (int)$_POST['product_id'];

    $sql = "SELECT InStock FROM Products WHERE ProductID = ?";
    $stmt = sqlsrv_query($conn, $sql, array($productID));
    $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
    if ($row) {
    $newStock = $row['InStock'] ? 0 : 1;

    // Set quantity 0 if marking out of stock, or default 50 if marking in stock
    $quantity = $newStock == 0 ? 0 : 50;

    $update_sql = "UPDATE Products SET InStock = ?, QuantityInStock = ? WHERE ProductID = ?";
    sqlsrv_query($conn, $update_sql, array($newStock, $quantity, $productID));
}

    header('Location: manage_stock.php');
    exit();
}

// Handle delete product request
if (isset($_POST['delete_product']) && isset($_POST['product_id'])) {
    $productID = (int)$_POST['product_id'];
    $delete_sql = "DELETE FROM Products WHERE ProductID = ?";
    $delete_stmt = sqlsrv_query($conn, $delete_sql, array($productID));
    if ($delete_stmt === false) {
        die(print_r(sqlsrv_errors(), true));
    }
    header('Location: manage_stock.php');
    exit();
}

// Fetch all products
$sql = "SELECT ProductID, ProductName, InStock FROM Products ORDER BY ProductName";
$result = sqlsrv_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Manage Stock - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <style>
        body {
            min-height: 100vh;
            background: url('assets/images/background.jpg') no-repeat center center fixed;
            background-size: cover;
            font-family: 'Segoe UI', sans-serif;
            display: flex;
            flex-direction: column;
        }
        .stock-in { color: green; font-weight: bold; }
        .stock-out { color: red; font-weight: bold; }
        .btn-toggle, .btn-delete { min-width: 130px; margin-right: 5px; }
        h2 {
            color: #c71585;
            font-family: 'Caveat', cursive;
            margin-bottom: 30px;
        }
    </style>
</head>
<body>
<div class="container mt-5">
    <h2>Manage Product Stock</h2>

    <table class="table table-striped table-bordered bg-white shadow-sm">
        <thead>
            <tr>
                <th>Product Name</th>
                <th>Stock Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) : ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['ProductName']); ?></td>
                    <td>
                        <?php if ($row['InStock']) : ?>
                            <span class="stock-in">In Stock</span>
                        <?php else : ?>
                            <span class="stock-out">Out of Stock</span>
                        <?php endif; ?>
                    </td>
                    <td class="d-flex">
                        <!-- Toggle Stock Button -->
                        <form method="POST" style="margin: 0;">
                            <input type="hidden" name="product_id" value="<?php echo $row['ProductID']; ?>">
                            <button type="submit" name="toggle_stock" class="btn btn-sm btn-toggle btn-primary">
                                <?php echo $row['InStock'] ? 'Mark Out of Stock' : 'Mark In Stock'; ?>
                            </button>
                        </form>

                        <!-- Delete Product Button -->
                        <form method="POST" style="margin: 0;" onsubmit="return confirm('Are you sure you want to delete this product?');">
                            <input type="hidden" name="product_id" value="<?php echo $row['ProductID']; ?>">
                            <button type="submit" name="delete_product" class="btn btn-sm btn-delete btn-danger">
                                Delete
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <a href="admin_dashboard.php" class="btn btn-secondary mt-3">Back to Dashboard</a>
</div>
</body>
</html>
