<?php
session_start();
include('includes/db.php');
include('includes/header.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$userID = $_SESSION['user_id'];

// Fetch the most recent order
$sqlOrder = "SELECT TOP 1 * FROM Orders WHERE UserID = ? ORDER BY OrderDate DESC";
$stmtOrder = sqlsrv_query($conn, $sqlOrder, array($userID));
$order = sqlsrv_fetch_array($stmtOrder, SQLSRV_FETCH_ASSOC);

if (!$order) {
    echo "<div class='container mt-5 text-center text-danger'>No recent order found.</div>";
    exit();
}

$orderID = $order['OrderID'];
$orderDate = $order['OrderDate']->format('Y-m-d H:i');
$deliveryAddress = $order['DeliveryAddress'];
$status = $order['Status'];

// Fetch items in the order
$sqlItems = "SELECT OI.Quantity, OI.TotalPrice, P.ProductName, P.ImageURL 
             FROM OrderItems OI 
             JOIN Products P ON OI.ProductID = P.ProductID 
             WHERE OI.OrderID = ?";
$stmtItems = sqlsrv_query($conn, $sqlItems, array($orderID));
?>

<style>
body {
    background: url('assets/images/background.jpg') no-repeat center center fixed;
            background-size: cover;
    font-family: 'Segoe UI', sans-serif;
}
.receipt-card {
    background: rgba(255, 255, 255, 0.85);
    backdrop-filter: blur(10px);
    border-radius: 20px;
    padding: 30px;
    box-shadow: 0 8px 20px rgba(128, 0, 128, 0.2);
}
.receipt-title {
    color: #9c27b0;
}
.track-btn {
    background-color: #ba68c8;
    color: white;
    font-weight: bold;
}
.track-btn:hover {
    background-color: #ab47bc;
}
</style>

<div class="container my-5">
    <div class="receipt-card">
        <h2 class="text-center receipt-title">Thank You for Your Purchase!</h2>
        <p class="text-center text-muted">Your order <strong>#<?php echo $orderID; ?></strong> was placed on <strong><?php echo $orderDate; ?></strong></p>
        
        <hr>

        <h4>Delivery Address:</h4>
        <p><?php echo htmlspecialchars($deliveryAddress); ?></p>

        <h4>Order Summary:</h4>
        <div class="row">
            <?php
            $grandTotal = 0;
            while ($item = sqlsrv_fetch_array($stmtItems, SQLSRV_FETCH_ASSOC)) {
                $grandTotal += $item['TotalPrice'];
            ?>
                <div class="col-md-6 mb-3">
                    <div class="card shadow-sm border-0 h-100">
                        <img src="<?php echo htmlspecialchars($item['ImageURL']); ?>" class="card-img-top" style="max-height: 200px; object-fit: contain;">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo htmlspecialchars($item['ProductName']); ?></h5>
                            <p class="card-text">Quantity: <?php echo $item['Quantity']; ?></p>
                            <p class="card-text text-success">Subtotal: $. <?php echo number_format($item['TotalPrice'], 2); ?></p>
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>

        <h4 class="mt-4">Total Paid: <span class="text-success">$. <?php echo number_format($grandTotal, 2); ?></span></h4>

        <div class="alert alert-info mt-3">
            🎉 Your order is confirmed and will be delivered within <strong>3–5 working days</strong>.<br>
            We’ll keep you updated on its status!
        </div>

        <form action="track_order.php" method="GET" class="text-center mt-4">
            <input type="hidden" name="order_id" value="<?php echo $orderID; ?>">
            <button class="btn track-btn px-4 py-2 rounded-pill">Track Order</button>
        </form>
    </div>
</div>
