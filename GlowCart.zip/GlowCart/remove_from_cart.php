<?php
session_start();
include('includes/db.php');

if (isset($_GET['cart_id']) && isset($_SESSION['user_id'])) {
    $cartID = $_GET['cart_id'];
    $userID = $_SESSION['user_id'];

    $sql = "DELETE FROM carttwo WHERE CartID = ? AND UserID = ?";
    $params = array($cartID, $userID);
    $stmt = sqlsrv_query($conn, $sql, $params);

    if ($stmt) {
        header("Location: cart.php");
        exit;
    } else {
        echo "Error removing item from cart.";
    }
} else {
    echo "Invalid request.";
}
?>
