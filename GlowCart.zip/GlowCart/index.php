<?php 
session_start();
include('includes/db.php');
include('includes/header.php');
?>

<!-- Custom CSS for background, cards, slider, and filter -->
<style>
    @import url('https://fonts.googleapis.com/css2?family=Lobster&family=Poppins:wght@400;600;700&display=swap');

    body {
    background: url('assets/images/background.jpg') no-repeat center center fixed;
    background-size: cover;
    font-family: 'Segoe UI', sans-serif;
}

.card {
    background: rgba(255, 255, 255, 0.12);
    border: 1px solid #ffffff30;
    backdrop-filter: blur(14px);
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.3);
    color: #ffffff;
    transition: transform 0.3s;
    display: flex;
    flex-direction: column;
    height: 480px;
    border-radius: 12px;
}

.card:hover {
    transform: translateY(-5px);
}

.card-img-top {
    height: 180px;
    object-fit: contain;
    padding: 10px;
    background: #fff;
    border-top-left-radius: 0.25rem;
    border-top-right-radius: 0.25rem;
    cursor: pointer;
    transition: transform 0.3s ease;
}

.card-img-top:hover {
    transform: scale(1.05);
}

.card-body {
    flex: 1 1 auto;
    display: flex;
    flex-direction: column;
    padding: 15px;
    background-color: transparent;
}

.card-title {
    font-family: 'Playfair Display', serif;
    font-weight: 700;
    color:rgb(163, 88, 113);
    font-size: 1.4rem;
    text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.6);
    margin-bottom: 8px;
}

.card-description {
    font-family: 'Open Sans', sans-serif;
    font-size: 1rem;
    color: #F8F8FF;
    line-height: 1.5;
    font-weight: 400;
    flex-grow: 1;
    margin-bottom: 10px;
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
}

.category-text {
    font-family: 'Nunito Sans', sans-serif;
    font-size: 0.85rem;
    font-style: italic;
    color: #FFC0CB;
    margin-bottom: 6px;
}

.card-price {
    font-family: 'Montserrat', sans-serif;
    font-size: 1.1rem;
    color: #FF4D4D;
    font-weight: 600;
    margin-bottom: 6px;
}

.card-stock.in-stock {
    font-family: 'Open Sans', sans-serif;
    color: #00FF7F;
    font-size: 0.95rem;
    font-weight: 500;
    margin-bottom: 12px;
}

.card-stock.out-stock {
    color: #a80000;
    font-size: 0.95rem;
    font-weight: 500;
    margin-bottom: 12px;
}

.btn {
    border-radius: 25px;
    font-weight: 600;
    transition: background-color 0.3s ease;
    font-family: 'Poppins', sans-serif;
    background-color: #FF69B4;
    color: white;
    padding: 10px 20px;
    border: none;
}

.btn:hover {
    background-color: #FF1493 !important;
}

.slider {
    width: 100%;
    overflow: hidden;
    margin: 20px auto;
    border-radius: 10px;
}

.slider-track {
    display: flex;
    animation: scroll 15s linear infinite;
}

.slider-track img {
    width: 100%;
    height: 300px;
    object-fit: cover;
}

@keyframes scroll {
    0% { transform: translateX(0); }
    100% { transform: translateX(-100%); }
}

.filter-buttons {
    text-align: center;
    margin-bottom: 20px;
}

.filter-buttons button {
    background-color: #ff69b4;
    color: white;
    margin: 5px;
    border: none;
    padding: 10px 20px;
    border-radius: 20px;
    transition: 0.3s;
    cursor: pointer;
    font-weight: 600;
    font-family: 'Segoe UI', sans-serif;
}

.filter-buttons button:hover {
    background-color: #c71585;
}
</style>

<!-- Image Slider -->
<div class="slider">
    <div class="slider-track">
        <img src="assets/images/sidebar1.jpg" alt="Slide 1">
        <img src="assets/images/sidebar2.jpg" alt="Slide 2">
        <img src="assets/images/sidebar3.jpg" alt="Slide 3">
        <img src="assets/images/sidebar1.jpg" alt="Slide 1">
        <img src="assets/images/sidebar2.jpg" alt="Slide 2">
        <img src="assets/images/sidebar3.jpg" alt="Slide 3">
    </div>
</div>

<!-- Filter Buttons -->
<div class="filter-buttons">
    <button onclick="filterProducts('all')">All</button>
    <button onclick="filterProducts('Skincare')">Skincare</button>
    <button onclick="filterProducts('Haircare')">Haircare</button>
    <button onclick="filterProducts('Makeup')">Makeup</button>
</div>

<div class="container">
    <div class="row" id="product-container">
       <?php
$sql = "SELECT * FROM Products";
$stmt = sqlsrv_query($conn, $sql);

if ($stmt) {
    while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        $productID = $row['ProductID'];
        $productName = htmlspecialchars($row['ProductName']);
        $price = $row['Price'];
        $category = htmlspecialchars($row['Category']);
        $description = htmlspecialchars($row['Description'] ?? 'No description available');

        // ✅ Image URL handling
        $image = 'assets/images/default.jpg';
        if (!empty($row['ImageURL'])) {
            $url = trim($row['ImageURL']);
            if (filter_var($url, FILTER_VALIDATE_URL)) {
                $image = $url;
            } elseif (file_exists($url)) {
                $image = $url;
            }
        }

        $inStock = $row['InStock'] ? 'In Stock' : 'Out of Stock';
?>
    <div class="col-md-4 mb-4 product-card" data-category="<?php echo strtolower($category); ?>">
        <div class="card h-100">
            <img src="<?php echo $image; ?>" class="card-img-top" alt="<?php echo $productName; ?>" onclick="openLightbox('<?php echo $image; ?>')">
            <div class="card-body d-flex flex-column">
                <h5 class="card-title"><?php echo $productName; ?></h5>
                <p class="card-description"><?php echo $description; ?></p>
                <p class="card-text category-text">Category: <?php echo $category; ?></p>
                <p class="card-price">$<?php echo number_format($price, 2); ?></p>
                <p class="card-stock <?php echo $row['InStock'] ? 'in-stock' : 'out-stock'; ?>"><?php echo $inStock; ?></p>
                <a href="add_to_cart.php?product_id=<?php echo $productID; ?>" class="btn btn-sm mt-auto" style="background-color: #ff69b4; color: white;">Add to Cart</a>
            </div>
        </div>
    </div>
<?php
    }
} else {
    echo "<p>No products found.</p>";
}
?>

    </div>
</div>

<!-- Lightbox Modal -->
<div id="lightbox" onclick="closeLightbox()" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.9); justify-content:center; align-items:center; z-index:9999;">
    <img id="lightbox-img" src="" style="max-width:80%; max-height:80%;">
</div>

<script>
    function filterProducts(category) {
        let cards = document.querySelectorAll('.product-card');
        cards.forEach(card => {
            if (category === 'all' || card.dataset.category === category.toLowerCase()) {
                card.style.display = 'block';
            } else {
                card.style.display = 'none';
            }
        });
    }

    function openLightbox(src) {
        document.getElementById('lightbox-img').src = src;
        document.getElementById('lightbox').style.display = 'flex';
    }

    function closeLightbox() {
        document.getElementById('lightbox').style.display = 'none';
    }
</script>

<?php include('includes/footer.php'); ?>
