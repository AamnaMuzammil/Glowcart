<?php 
session_start();
include('includes/db.php');
include('includes/header.php');

$userID = $_SESSION['user_id'] ?? null;
if (!$userID) {
    echo "<div class='container mt-5'><h3>Please <a href='login.php'>login</a> to view your cart.</h3></div>";
    include('includes/footer.php');
    exit;
}

$sql = "SELECT c.CartID, p.ProductName, p.Price, c.Quantity, p.ImageURL, p.ProductID
        FROM carttwo c
        JOIN Products p ON c.ProductID = p.ProductID
        WHERE c.UserID = ?";
$params = array($userID);
$stmt = sqlsrv_query($conn, $sql, $params);

$total = 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>GlowCart - Cart</title>
    <style>
        html, body {
            margin: 0;
            padding: 0;
            background: url('assets/images/background.jpg') no-repeat center center fixed;
            background-size: cover;
            font-family: 'Segoe UI', sans-serif;
            color: #fff;
            min-height: 100vh;
        }

        .wrapper {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        .content {
            flex: 1;
        }

        .blur-card {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 20px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.3);
            animation: fadeIn 1s ease;
        }

        h2 {
            text-shadow: 2px 2px 8px rgba(0,0,0,0.6);
            font-family: 'Caveat', cursive;
            color: #ff69b4;
        }

        table {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(8px);
            border-radius: 10px;
            overflow: hidden;
        }

        table thead {
            background: rgba(255, 105, 180, 0.7);
        }

        table td, table th {
            color: #fff;
        }

        .btn {
            transition: 0.3s;
            border-radius: 50px;
        }

        .btn:hover {
            transform: scale(1.05);
            background: #ff1493 !important;
        }

        footer {
            background: rgba(0, 0, 0, 0.7);
            color: #fff;
            text-align: center;
            padding: 10px;
            backdrop-filter: blur(8px);
            font-weight: bold;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>

<div class="wrapper">
    <div class="content container mt-5">
        <h2 class="text-center mb-4">🛒 Your Cart</h2>

        <div class="blur-card">
            <table class="table table-bordered text-center">
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Image</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Subtotal</th>
                        <th>Remove</th>
                    </tr>
                </thead>
                <tbody>
                <?php while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)): 
    $subtotal = $row['Price'] * $row['Quantity'];
    $total += $subtotal;
    $imgPath = $row['ImageURL']; // ✅ updated here
?>
<tr>
    <td><?= htmlspecialchars($row['ProductName']) ?></td>
    <td><img src="<?= $imgPath ?>" style="height:80px; border-radius:10px;"></td>
    <td>$<?= number_format($row['Price'], 2) ?></td>
    <td><?= $row['Quantity'] ?></td>
    <td>$<?= number_format($subtotal, 2) ?></td>
    <td><a href="remove_from_cart.php?cart_id=<?= $row['CartID'] ?>" class="btn btn-danger btn-sm">Remove</a></td>
</tr>
<?php endwhile; ?>

                <tr style="font-weight:bold;">
                    <td colspan="4" class="text-end">Grand Total</td>
                    <td colspan="2">$<?= number_format($total, 2) ?></td>
                </tr>
                </tbody>
            </table>
            <div class="text-end">
                <a href="checkout.php" class="btn" style="background:#ff69b4; color:white;">Proceed to Checkout</a>
            </div>
        </div>
    </div>

    <?php include('includes/footer.php'); ?>
</div>

</body>
</html>
