<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['card_name'];
    $number = $_POST['card_number'];
    $expiry = $_POST['expiry'];
    $cvv = $_POST['cvv'];

    // Normally you'd securely process payment via gateway API here.
    echo "<h2 style='text-align:center;color:green;'>Payment Successful! 🎉</h2>";
    // You can log, redirect or email the admin.
} else {
    header("Location: debit_payment.php");
    exit;
}
?>
