<?php
include('includes/db.php');
include('includes/header.php');

$totalOrders = $cancelledOrders = 0;
$categoryData = [];
$topProducts = [];

// Orders (Delivered & Cancelled)
$stmt1 = sqlsrv_query($conn, "SELECT 
    SUM(CASE WHEN Status = 'Delivered' THEN 1 ELSE 0 END) AS Delivered, 
    SUM(CASE WHEN Status = 'Cancelled' THEN 1 ELSE 0 END) AS Cancelled 
FROM Orders");
if ($stmt1 && $row = sqlsrv_fetch_array($stmt1, SQLSRV_FETCH_ASSOC)) {
    $totalOrders = $row['Delivered'];
    $cancelledOrders = $row['Cancelled'];
}

// Category Sales
$stmt2 = sqlsrv_query($conn, "SELECT Category, SUM(TotalSold) AS TotalSold FROM vw_CategorySales GROUP BY Category");
while ($row = sqlsrv_fetch_array($stmt2, SQLSRV_FETCH_ASSOC)) {
    $categoryData[$row['Category']] = $row['TotalSold'];
}
$defaultCategories = ['Skincare' => 0, 'Makeup' => 0, 'Haircare' => 0];
$categoryData = array_merge($defaultCategories, $categoryData);

// Top Products
$stmt3 = sqlsrv_query($conn, "EXEC sp_GetTopSellingProducts");
while ($row = sqlsrv_fetch_array($stmt3, SQLSRV_FETCH_ASSOC)) {
    $topProducts[] = $row;
}
?>

<!-- Fonts & Chart.js -->
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600&family=Poppins:wght@400;600&display=swap" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<!-- Styles -->
<style>
  body {
    margin: 0;
    font-family: 'Poppins', sans-serif;
    background: url('assets/images/background.jpg') no-repeat center center fixed;
    background-size: cover;
    backdrop-filter: blur(3px);
  }

  .graph-wrapper {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(360px, 1fr));
    gap: 30px;
    padding: 60px 40px;
    max-width: 1200px;
    margin: auto;
  }

  .chart-box {
    background: rgba(255, 255, 255, 0.8);
    border-radius: 16px;
    padding: 25px;
    box-shadow: 0 8px 25px rgba(199, 21, 133, 0.2);
    transition: all 0.3s ease;
    backdrop-filter: blur(10px);
    display: flex;
    flex-direction: column;
    justify-content: center;
  }

  .chart-box:hover {
    transform: translateY(-6px);
    box-shadow: 0 12px 30px rgba(199, 21, 133, 0.25);
  }

  .chart-box h3 {
    font-family: 'Playfair Display', serif;
    font-size: 22px;
    color: #8e24aa;
    text-align: center;
    margin-bottom: 20px;
  }

  canvas {
    width: 100% !important;
    height: 250px !important;
  }

  @media (max-width: 768px) {
    .graph-wrapper {
      padding: 30px 20px;
      grid-template-columns: 1fr;
    }
  }
</style>

<!-- Graph UI -->
<div class="graph-wrapper">
  <!-- Orders Chart -->
  <div class="chart-box" style="grid-column: span 1;">
    <h3>📦 Orders Overview</h3>
    <canvas id="ordersBar"></canvas>
  </div>

  <!-- Category Sales -->
  <div class="chart-box" style="grid-column: span 1;">
    <h3>💄 Sales by Category</h3>
    <canvas id="categoryChart"></canvas>
  </div>

  <!-- Top Products -->
  <div class="chart-box" style="grid-column: span 2; height: 380px;">
    <h3>🌟 Top 5 Products (Line Graph)</h3>
    <canvas id="topLineChart" style="height: 300px !important;"></canvas>
  </div>
</div>

<!-- Chart Config -->
<script>
  // Orders
  new Chart(document.getElementById('ordersBar').getContext('2d'), {
    type: 'bar',
    data: {
      labels: ['Delivered', 'Cancelled'],
      datasets: [{
        data: [<?= $totalOrders ?>, <?= $cancelledOrders ?>],
        backgroundColor: ['#66bb6a', '#ef5350'],
        borderRadius: 6
      }]
    },
    options: {
      indexAxis: 'y',
      responsive: true,
      plugins: { legend: { display: false } },
      scales: { x: { beginAtZero: true } }
    }
  });

  // Category Sales
  new Chart(document.getElementById('categoryChart').getContext('2d'), {
    type: 'doughnut',
    data: {
      labels: <?= json_encode(array_keys($categoryData)) ?>,
      datasets: [{
        label: 'Total Sold',
        data: <?= json_encode(array_values($categoryData)) ?>,
        backgroundColor: ['#f48fb1', '#ba68c8', '#81d4fa'],
        borderColor: '#fff',
        borderWidth: 2
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: {
          position: 'bottom',
          labels: { color: '#444', font: { size: 14 } }
        },
        tooltip: {
          callbacks: {
            label: context => ` ${context.label}: ${context.raw || 0} sold`
          }
        }
      }
    }
  });

  // Top 5 Products
  new Chart(document.getElementById('topLineChart').getContext('2d'), {
    type: 'line',
    data: {
      labels: <?= json_encode(array_column($topProducts, 'ProductName')) ?>,
      datasets: [{
        label: 'Units Sold',
        data: <?= json_encode(array_column($topProducts, 'TotalSold')) ?>,
        borderColor: '#6A1B9A',
        backgroundColor: '#6A1B9A',
        fill: false,
        tension: 0.4,
        pointRadius: 4,
        pointBackgroundColor: '#6A1B9A'
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: {
          position: 'top',
          labels: { font: { size: 14 } }
        }
      },
      scales: {
        y: { beginAtZero: true },
        x: { ticks: { color: '#444', font: { size: 13 } } }
      }
    }
  });
</script>

<?php include('includes/footer.php'); ?>
