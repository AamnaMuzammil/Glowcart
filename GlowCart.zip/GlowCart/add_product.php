<?php  
session_start();
include('includes/db.php');
include('includes/header.php');

$productID = $_GET['product_id'] ?? null;
$isEdit = $productID !== null;

$productName = '';
$price = '';
$imageURL = '';
$category = '';
$skinTone = '';
$skinType = '';
$hairType = '';
$inStock = 1;
$description = '';
$brandName = '';
$quantityInStock = 0;
$message = '';

if ($isEdit) {
    $sql = "SELECT * FROM Products WHERE ProductID = ?";
    $params = [$productID];
    $stmt = sqlsrv_query($conn, $sql, $params);

    if ($stmt && $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        $productName = $row['ProductName'];
        $price = $row['Price'];
        $imageURL = $row['ImageURL'];
        $category = $row['Category'];
        $skinTone = $row['SkinTone'];
        $skinType = $row['SkinType'];
        $hairType = $row['HairType'];
        $inStock = $row['InStock'];
        $description = $row['Description'];
        $brandName = $row['BrandName'];
        $quantityInStock = $row['QuantityInStock'];
    } else {
        echo "<p>Product not found.</p>";
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $productName = $_POST['product_name'] ?? '';
    $price = floatval($_POST['price'] ?? 0);
    $category = $_POST['category'] ?? '';
    $skinTone = $_POST['skin_tone'] ?? null;
    $skinType = $_POST['skin_type'] ?? null;
    $hairType = $_POST['hair_type'] ?? null;
    $inStock = isset($_POST['in_stock']) ? 1 : 0;
    $description = $_POST['description'] ?? '';
    $brandName = $_POST['brand_name'] ?? '';
    $externalImageURL = $_POST['external_image_url'] ?? '';
    $quantityInStock = intval($_POST['quantity'] ?? 0);

    $uploadDir = 'uploads/';
    $newImageURL = $imageURL;

    if (!empty($externalImageURL)) {
        $newImageURL = $externalImageURL;
    } elseif (isset($_FILES['product_image']) && $_FILES['product_image']['error'] != UPLOAD_ERR_NO_FILE) {
        $file = $_FILES['product_image'];
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
        $maxSize = 2 * 1024 * 1024;

        if (!in_array($file['type'], $allowedTypes)) {
            $message = "Invalid file type. Only JPG, PNG, GIF allowed.";
        } elseif ($file['size'] > $maxSize) {
            $message = "File too large. Max 2MB allowed.";
        } else {
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }

            $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
            $newFileName = uniqid('prod_', true) . '.' . $ext;
            $destination = $uploadDir . $newFileName;

            if (move_uploaded_file($file['tmp_name'], $destination)) {
                $newImageURL = $destination;
            } else {
                $message = "Failed to upload image.";
            }
        }
    } else {
        if (!$isEdit && empty($externalImageURL)) {
            $message = "Please provide an image (upload or URL).";
        }
    }

    if ($message === '') {
        if ($isEdit) {
            $updateSql = "UPDATE Products 
                          SET ProductName = ?, Price = ?, ImageURL = ?, Category = ?, SkinTone = ?, SkinType = ?, HairType = ?, InStock = ?, Description = ?, BrandName = ?, QuantityInStock = ? 
                          WHERE ProductID = ?";
            $params = [$productName, $price, $newImageURL, $category, $skinTone, $skinType, $hairType, $inStock, $description, $brandName, $quantityInStock, $productID];
            $stmt = sqlsrv_query($conn, $updateSql, $params);

            $message = $stmt ? "✅ Product updated successfully." : "❌ Error updating product.";
        } else {
            $insertSql = "INSERT INTO Products 
                          (ProductName, Price, ImageURL, Category, SkinTone, SkinType, HairType, InStock, Description, BrandName, QuantityInStock) 
                          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $params = [$productName, $price, $newImageURL, $category, $skinTone, $skinType, $hairType, $inStock, $description, $brandName, $quantityInStock];
            $stmt = sqlsrv_query($conn, $insertSql, $params);

            if ($stmt) {
                $message = "✅ Product added successfully.";
                $productName = $price = $category = $skinTone = $skinType = $hairType = $description = $brandName = '';
                $inStock = 1;
                $quantityInStock = 0;
                $imageURL = '';
            } else {
                $message = "❌ Error adding product.";
            }
        }
    }
}
?>

<!-- HTML + Bootstrap Form -->
<style>
    body {
        min-height: 100vh;
        background: url('assets/images/background.jpg') no-repeat center center fixed;
        background-size: cover;
        font-family: 'Segoe UI', sans-serif;
        display: flex;
        flex-direction: column;
        color: white;
    }
</style>

<div class="container mt-5">
    <h2><?php echo $isEdit ? 'Edit Product' : 'Add New Product'; ?></h2>

    <?php if ($message): ?>
        <div class="alert alert-info"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>

    <form method="POST" action="" enctype="multipart/form-data">
        <div class="mb-3">
            <label for="product_name" class="form-label">Product Name *</label>
            <input type="text" class="form-control" id="product_name" name="product_name" required value="<?php echo htmlspecialchars($productName); ?>">
        </div>

        <div class="mb-3">
            <label for="price" class="form-label">Price *</label>
            <input type="number" step="0.01" min="0" class="form-control" id="price" name="price" required value="<?php echo htmlspecialchars($price); ?>">
        </div>

        <div class="mb-3">
            <label for="quantity" class="form-label">Quantity In Stock *</label>
            <input type="number" class="form-control" id="quantity" name="quantity" required min="0" value="<?php echo htmlspecialchars($quantityInStock); ?>">
        </div>

        <div class="mb-3">
            <label for="product_image" class="form-label"><?php echo $isEdit ? 'Change Image (optional)' : 'Product Image *'; ?></label>
            <input type="file" class="form-control" id="product_image" name="product_image" <?php echo $isEdit ? '' : 'required'; ?> accept="image/*">
        </div>

        <div class="mb-3">
            <label for="external_image_url" class="form-label">OR External Image URL</label>
            <input type="url" class="form-control" id="external_image_url" name="external_image_url" placeholder="https://example.com/image.jpg">
        </div>

        <?php if ($imageURL): ?>
            <img src="<?php echo htmlspecialchars($imageURL); ?>" alt="Product Image" style="max-width:150px; margin-top:10px;">
        <?php endif; ?>

        <div class="mb-3">
            <label for="category" class="form-label">Category *</label>
            <select class="form-select" id="category" name="category" required>
                <option value="" disabled <?php echo $category == '' ? 'selected' : ''; ?>>Select Category</option>
                <option value="Makeup" <?php echo $category == 'Makeup' ? 'selected' : ''; ?>>Makeup</option>
                <option value="Skincare" <?php echo $category == 'Skincare' ? 'selected' : ''; ?>>Skin Care</option>
                <option value="Haircare" <?php echo $category == 'Haircare' ? 'selected' : ''; ?>>Hair Care</option>
            </select>
        </div>

        <div class="mb-3">
            <label for="description" class="form-label">Product Description</label>
            <textarea class="form-control" id="description" name="description" rows="3"><?php echo htmlspecialchars($description); ?></textarea>
        </div>

        <div class="mb-3">
            <label for="brand_name" class="form-label">Brand Name</label>
            <input type="text" class="form-control" id="brand_name" name="brand_name" value="<?php echo htmlspecialchars($brandName); ?>">
        </div>

        <div class="mb-3">
            <label for="skin_tone" class="form-label">Skin Tone (optional)</label>
            <select class="form-select" id="skin_tone" name="skin_tone">
                <option value="" <?php echo $skinTone == '' ? 'selected' : ''; ?>>None</option>
                <option value="Fair" <?php echo $skinTone == 'Fair' ? 'selected' : ''; ?>>Fair</option>
                <option value="Medium" <?php echo $skinTone == 'Medium' ? 'selected' : ''; ?>>Medium</option>
                <option value="Dark" <?php echo $skinTone == 'Dark' ? 'selected' : ''; ?>>Dark</option>
            </select>
        </div>

        <div class="mb-3">
            <label for="skin_type" class="form-label">Skin Type (optional)</label>
            <select class="form-select" id="skin_type" name="skin_type">
                <option value="" <?php echo $skinType == '' ? 'selected' : ''; ?>>None</option>
                <option value="Oily" <?php echo $skinType == 'Oily' ? 'selected' : ''; ?>>Oily</option>
                <option value="Dry" <?php echo $skinType == 'Dry' ? 'selected' : ''; ?>>Dry</option>
                <option value="Combination" <?php echo $skinType == 'Combination' ? 'selected' : ''; ?>>Combination</option>
                <option value="Sensitive" <?php echo $skinType == 'Sensitive' ? 'selected' : ''; ?>>Sensitive</option>
            </select>
        </div>

        <div class="mb-3">
            <label for="hair_type" class="form-label">Hair Type (optional)</label>
            <select class="form-select" id="hair_type" name="hair_type">
                <option value="" <?php echo $hairType == '' ? 'selected' : ''; ?>>None</option>
                <option value="Straight" <?php echo $hairType == 'Straight' ? 'selected' : ''; ?>>Straight</option>
                <option value="Curly" <?php echo $hairType == 'Curly' ? 'selected' : ''; ?>>Curly</option>
                <option value="Wavy" <?php echo $hairType == 'Wavy' ? 'selected' : ''; ?>>Wavy</option>
                <option value="Dry" <?php echo $hairType == 'Dry' ? 'selected' : ''; ?>>Dry</option>
                <option value="Oily" <?php echo $hairType == 'Oily' ? 'selected' : ''; ?>>Oily</option>
                <option value="Damaged" <?php echo $hairType == 'Damaged' ? 'selected' : ''; ?>>Damaged</option>
                <option value="Rough" <?php echo $hairType == 'Rough' ? 'selected' : ''; ?>>Rough</option>
            </select>
        </div>

        <div class="mb-3 form-check">
            <input type="checkbox" class="form-check-input" id="in_stock" name="in_stock" <?php echo $inStock ? 'checked' : ''; ?>>
            <label class="form-check-label" for="in_stock">In Stock</label>
        </div>

        <button type="submit" class="btn btn-primary"><?php echo $isEdit ? 'Update Product' : 'Add Product'; ?></button>
    </form>
</div>

<?php include('includes/footer.php'); ?>
