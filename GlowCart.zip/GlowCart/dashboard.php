<?php
session_start();
include('includes/db.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$userID = $_SESSION['user_id'];
$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_preferences'])) {
    $skinType = $_POST['skin_type'];
    $skinTone = $_POST['skin_tone'];
    $hairType = $_POST['hair_type'];

    $prefSql = "UPDATE Users SET SkinType = ?, SkinTone = ?, HairType = ? WHERE UserID = ?";
    $prefParams = array($skinType, $skinTone, $hairType, $userID);
    $prefStmt = sqlsrv_query($conn, $prefSql, $prefParams);

    if ($prefStmt) {
        header("Location: skincare.php");
        exit();
    }
}

$fetchSql = "SELECT * FROM Users WHERE UserID = ?";
$fetchStmt = sqlsrv_query($conn, $fetchSql, array($userID));
$userData = sqlsrv_fetch_array($fetchStmt, SQLSRV_FETCH_ASSOC);

include('includes/header.php');
?>

<!-- 🎨 STYLES -->
<style>
html, body {
    height: 100%;
    margin: 0;
    font-family: 'Poppins', sans-serif;
    background: url('assets/images/background.jpg') no-repeat center center fixed;
    background-size: cover;
    display: flex;
    flex-direction: column;
}

body > .main-content {
    flex: 1;
    padding-top: 90px; /* Space for sticky navbar */
}

.navbar {
    position: fixed;
    top: 0;
    width: 100%;
    z-index: 999;
    background: linear-gradient(90deg, #8b008b, #c71585, #ff1493);
    box-shadow: 0 4px 20px rgba(139, 0, 139, 0.3);
}

.card-glow {
    background: rgba(255, 255, 255, 0.9);
    border-radius: 15px;
    box-shadow: 0 10px 25px rgba(174, 0, 255, 0.2);
    padding: 50px;
    margin-bottom: 30px;
}

.profile-header img {
    width: 90px;
    height: 90px;
    border-radius: 50%;
    border: 3px solid #ff69b4;
    box-shadow: 0 0 10px rgba(255, 105, 180, 0.5);
}

.stats-boxes {
    display: flex;
    justify-content: space-between;
    gap: 20px;
    margin-top: 25px;
}

.stat {
    flex: 1;
    text-align: center;
    background: #ffe4f2;
    border-radius: 10px;
    padding: 15px;
    font-weight: bold;
    color: #8b008b;
    box-shadow: 0 4px 10px rgba(0,0,0,0.05);
}

.recommend-box {
    background: #fff0f6;
    border-left: 5px solid #ff69b4;
    padding: 20px;
    border-radius: 10px;
    margin-bottom: 40px;
}

footer {
    background: rgba(255, 255, 255, 0.15);
    text-align: center;
    padding: 50px;
    color: #fff;
    font-weight: 500;
    backdrop-filter: blur(8px);
    border-top: 1px solid rgba(255, 255, 255, 0.2);
}
</style>

<!-- 📦 DASHBOARD -->
<div class="container">
    <div class="card-glow profile-header">
        <img src="assets/images/profile.png" alt="Profile">
        <h3>Hello, <?= htmlspecialchars($userData['FullName']) ?></h3>
        <p class="text-muted">Manage your beauty preferences</p>
    </div>

    <div class="stats-boxes">
        <div class="stat">Skin Type<br><?= htmlspecialchars($userData['SkinType']) ?></div>
        <div class="stat">Skin Tone<br><?= htmlspecialchars($userData['SkinTone']) ?></div>
        <div class="stat">Hair Type<br><?= htmlspecialchars($userData['HairType']) ?></div>
    </div>

    <div class="card-glow">
        <h3>Update Preferences</h3>
        <form method="POST">
            <div class="mb-3">
                <label class="form-label">Skin Type</label>
                <select name="skin_type" class="form-select" required>
                    <option <?= ($userData['SkinType'] == 'Dry') ? 'selected' : ''; ?>>Dry</option>
                    <option <?= ($userData['SkinType'] == 'Oily') ? 'selected' : ''; ?>>Oily</option>
                    <option <?= ($userData['SkinType'] == 'Combination') ? 'selected' : ''; ?>>Combination</option>
                   
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Skin Tone</label>
                <select name="skin_tone" class="form-select" required>
                    <option <?= ($userData['SkinTone'] == 'Fair') ? 'selected' : ''; ?>>Fair</option>
                    <option <?= ($userData['SkinTone'] == 'Medium') ? 'selected' : ''; ?>>Medium</option>
                    <option <?= ($userData['SkinTone'] == 'Dark') ? 'selected' : ''; ?>>Dark</option>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Hair Type</label>
                <select name="hair_type" class="form-select" required>
                    <option <?= ($userData['HairType'] == 'Wavy') ? 'selected' : ''; ?>>Wavy</option>
                    <option <?= ($userData['HairType'] == 'Oily') ? 'selected' : ''; ?>>Oily</option>
                    <option <?= ($userData['HairType'] == 'Rough') ? 'selected' : ''; ?>>Rough</option>
                    <option <?= ($userData['HairType'] == 'Damaged') ? 'selected' : ''; ?>>Damaged</option>
                    <option <?= ($userData['HairType'] == 'Curly') ? 'selected' : ''; ?>>Curly</option>
                    <option <?= ($userData['HairType'] == 'Straight') ? 'selected' : ''; ?>>Straight</option>
                </select>
            </div>

            <button type="submit" name="update_preferences" class="btn btn-update mt-3">Save Preferences</button>
        </form>
    </div>

    <div class="recommend-box mt-4">
        <h5>🌟 Recommended for You</h5>
        <ul class="mb-0">
            <li>Hydrating Serum for <strong><?= $userData['SkinType'] ?></strong> skin</li>
            <li>Hair Mask for <strong><?= $userData['HairType'] ?></strong> hair</li>
            <li>Foundation for <strong><?= $userData['SkinTone'] ?></strong> skin tone</li>
        </ul>
    </div>
</div>

<?php include('includes/footer.php'); ?>
