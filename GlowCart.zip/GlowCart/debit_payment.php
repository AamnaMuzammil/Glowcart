<?php
session_start();
if (!isset($_SESSION['checkout_address'])) {
    header("Location: checkout.php");
    exit();
}
$address = $_SESSION['checkout_address'];
?>
<?php include('includes/header.php'); ?>


<style>
    body {
        background: url('assets/images/payment-bg.jpg') no-repeat center center fixed;
        background-size: cover;
        font-family: 'Poppins', sans-serif;
    }

    .payment-box {
        max-width: 480px;
        margin: 100px auto;
        padding: 30px;
        background: rgba(255, 255, 255, 0.95);
        border-radius: 20px;
        box-shadow: 0 12px 30px rgba(199, 21, 133, 0.2);
        backdrop-filter: blur(8px);
    }

    h2 {
        font-family: 'Playfair Display', serif;
        text-align: center;
        color: #c71585;
        margin-bottom: 25px;
    }

    .form-control {
        border-radius: 12px;
        padding: 10px 15px;
        font-size: 16px;
        margin-bottom: 20px;
    }

    .btn-pay {
        background: linear-gradient(45deg, #ff69b4, #c71585);
        color: white;
        border: none;
        padding: 12px;
        font-size: 18px;
        border-radius: 12px;
        width: 100%;
        font-weight: bold;
        transition: all 0.3s ease;
    }

    .btn-pay:hover {
        background: linear-gradient(45deg, #c71585, #ff69b4);
        transform: scale(1.03);
    }

    label {
        font-weight: 600;
        color: #6a1b9a;
    }
</style>

<div class="payment-box">
    <h2>💳 Debit Card Payment</h2>
    <form method="POST" action="process_debit_payment.php">
        <input type="hidden" name="address" value="<?= htmlspecialchars($address) ?>">

        <label>Cardholder Name</label>
        <input type="text" name="card_name" class="form-control" required placeholder="e.g. Sarah Ali">

        <label>Card Number</label>
        <input type="text" name="card_number" class="form-control" required maxlength="16" pattern="\d{13,16}" placeholder="xxxx xxxx xxxx xxxx">

        <label>Expiry Date</label>
        <input type="month" name="expiry" class="form-control" required>

        <label>CVV</label>
        <input type="password" name="cvv" class="form-control" required maxlength="4" pattern="\d{3,4}" placeholder="CVV">

        <button type="submit" class="btn-pay">Confirm Payment</button>
    </form>
</div>

<?php include('includes/footer.php'); ?>
