<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

function sendStatusEmail($conn, $orderID, $newStatus) {
    $sql = "SELECT U.Email, U.FullName, O.OrderDate
            FROM Orders O 
            JOIN Users U ON O.UserID = U.UserID
            WHERE O.OrderID = ?";
    $stmt = sqlsrv_query($conn, $sql, array($orderID));
    $order = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);

    if (!$order) return false;

    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'amnamuzammil131@gmail.com'; // Replace with your Gmail
        $mail->Password = 'ercx xvwx rtjy frym';   // Use Gmail App Password
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        $mail->setFrom('amnamuzammil131@gmail.com', 'GlowCart');
        $mail->addAddress($order['Email'], $order['FullName']);

        $mail->isHTML(true);
        $mail->Subject = "Your GlowCart Order #$orderID is now $newStatus!";
        $mail->Body = "
            <h3>Hi {$order['FullName']},</h3>
            <p>Your order <strong>#$orderID</strong> placed on <strong>{$order['OrderDate']->format('Y-m-d')}</strong> is now marked as <strong>$newStatus</strong>.</p>
            <p>Thanks for shopping with <strong>GlowCart</strong> 💖</p>
        ";

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("❌ Email failed: {$mail->ErrorInfo}");
        return false;
    }
}
?>
