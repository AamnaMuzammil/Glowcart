<?php
// register.php
include('includes/db.php');

$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $phone = $_POST['phone'];
    $location = $_POST['location'];
    $city = $_POST['city'];
    $country = $_POST['country'];

    if (!empty($name) && !empty($email) && !empty($password)) {
        $sql = "INSERT INTO Users (FullName, Email, Password, Phone, Location, City, Country) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $params = array($name, $email, $password, $phone, $location, $city, $country);
        $stmt = sqlsrv_query($conn, $sql, $params);

        if ($stmt) {
            $message = "Registration successful! Please <a href='login.php' style='color:#c71585;font-weight:bold;'>login</a>.";
        } else {
            $message = "Error: " . print_r(sqlsrv_errors(), true);
        }
    } else {
        $message = "Please fill all required fields.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>GlowCart Registration</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <style>
        body {
            background: url('assets/images/background.jpg') no-repeat center center fixed;
            background-size: cover;
            font-family: 'Segoe UI', sans-serif;
            animation: fadeIn 1s ease-in-out;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            padding-bottom: 60px; /* space for footer */
            box-sizing: border-box;
        }

        @keyframes fadeIn {
            0% {opacity: 0;}
            100% {opacity: 1;}
        }

        .card {
            width: 90%;
            max-width: 600px; /* increased horizontal size */
            background: rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border-radius: 20px;
            border: 1px solid rgba(255, 255, 255, 0.3);
            box-shadow: 0 8px 32px rgba(199, 21, 133, 0.3);
            animation: popIn 0.6s ease;
            color: #fff;
            padding: 20px 40px; /* more horizontal padding */
            max-height: 750px; /* smaller vertical height */
            overflow-y: auto; /* scroll if content overflows */
        }

        @keyframes popIn {
            0% { transform: scale(0.8); opacity: 0; }
            100% { transform: scale(1); opacity: 1; }
        }

        h2 {
            font-family: 'Caveat', cursive;
            font-size: 2.5rem;
            text-shadow: 2px 2px #ff69b4;
            color: #fff;
            text-align: center;
            margin-bottom: 1.5rem;
        }

        .form-label {
            color: #fff;
            font-weight: bold;
        }

        .form-label i {
            color: #ff69b4;
            margin-right: 8px;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }

        .form-control {
            background: rgba(255, 255, 255, 0.2);
            border: none;
            color: #fff;
            backdrop-filter: blur(5px);
        }

        .form-control::placeholder {
            color: #eee;
        }

        .btn-register {
            background: linear-gradient(45deg, #ff69b4, #c71585);
            color: white;
            border: none;
            border-radius: 30px;
            padding: 10px 25px;
            font-weight: bold;
            transition: all 0.3s ease;
            box-shadow: 0 0 15px rgba(255, 105, 180, 0.7);
            width: 100%;
            margin-top: 1rem;
        }

        .btn-register:hover {
            transform: translateY(-3px) scale(1.05);
            box-shadow: 0 0 25px rgba(255, 105, 180, 0.9);
        }

        .alert-info {
            background-color: rgba(255, 255, 255, 0.5);
            backdrop-filter: blur(5px);
            border: 1px solid #c71585;
            color: #c71585;
            font-weight: bold;
            border-radius: 10px;
            text-align: center;
            margin-top: 10px;
        }

        footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            height: 50px;
            background: rgba(199, 21, 133, 0.8);
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            font-weight: 600;
            font-family: 'Segoe UI', sans-serif;
            box-shadow: 0 -2px 10px rgba(199, 21, 133, 0.7);
            user-select: none;
            z-index: 100;
        }
    </style>
</head>
<body>
    <div class="card">
        <h2>GlowCart Registration</h2>
        <?php if ($message) { echo "<div class='alert alert-info'>$message</div>"; } ?>
        <form method="POST" action="">
            <div class="mb-3">
                <label class="form-label"><i class="fas fa-user"></i>Full Name</label>
                <input type="text" class="form-control" name="name" placeholder="Your Name" required />
            </div>
            <div class="mb-3">
                <label class="form-label"><i class="fas fa-envelope"></i>Email Address</label>
                <input type="email" class="form-control" name="email" placeholder="your@email.com" required />
            </div>
            <div class="mb-3">
                <label class="form-label"><i class="fas fa-lock"></i>Password</label>
                <input type="password" class="form-control" name="password" placeholder="Choose a password" required />
            </div>
            <div class="mb-3">
                <label class="form-label"><i class="fas fa-phone"></i>Phone Number</label>
                <input type="text" class="form-control" name="phone" placeholder="Optional" />
            </div>
            <div class="mb-3">
                <label class="form-label"><i class="fas fa-map-marker-alt"></i>Location</label>
                <input type="text" class="form-control" name="location" placeholder="Optional" />
            </div>
            <div class="mb-3">
                <label class="form-label"><i class="fas fa-city"></i>City</label>
                <input type="text" class="form-control" name="city" placeholder="Optional" />
            </div>
            <div class="mb-3">
                <label class="form-label"><i class="fas fa-flag"></i>Country</label>
                <input type="text" class="form-control" name="country" placeholder="Optional" />
            </div>
            <button type="submit" class="btn btn-register">
                <i class="fas fa-user-plus"></i> Register
            </button>
        </form>
    </div>

    <footer>
        &copy; <?php echo date('Y'); ?> GlowCart. All rights reserved.
    </footer>
</body>
</html>
