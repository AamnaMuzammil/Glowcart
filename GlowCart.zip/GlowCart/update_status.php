<?php
session_start();
include('includes/db.php');
include('send_status_update_email.php'); // this contains sendStatusEmail()

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $orderID = intval($_POST['order_id']);
    $newStatus = $_POST['status'];

    $sql = "UPDATE Orders SET Status = ? WHERE OrderID = ?";
    $stmt = sqlsrv_query($conn, $sql, array($newStatus, $orderID));

    if ($stmt) {
        // Email customer about new status
        sendStatusEmail($conn, $orderID, $newStatus);
        $_SESSION['msg'] = "Order #$orderID status updated to $newStatus and email sent!";
    } else {
        $_SESSION['msg'] = "Error updating order status.";
    }

    header("Location: view_orders.php");
    exit();
}
?>
