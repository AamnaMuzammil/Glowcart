<?php
session_start();
include('includes/db.php');
include('includes/header.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$userID = $_SESSION['user_id'];

$sql = "
SELECT o.OrderID, o.OrderDate, o.Status, o.PaymentMethod, o.DeliveryAddress,
       p.ProductName, p.ImageURL, oi.Quantity
FROM Orders o
JOIN OrderItems oi ON o.OrderID = oi.OrderID
JOIN Products p ON oi.ProductID = p.ProductID
WHERE o.UserID = ?
ORDER BY o.OrderDate DESC";

$stmt = sqlsrv_query($conn, $sql, array($userID));

$orders = [];

while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
    $orderID = $row['OrderID'];
    if (!isset($orders[$orderID])) {
        $orders[$orderID] = [
            'OrderDate' => $row['OrderDate'],
            'Status' => $row['Status'],
            'PaymentMethod' => $row['PaymentMethod'],
            'DeliveryAddress' => $row['DeliveryAddress'],
            'Items' => []
        ];
    }

    $orders[$orderID]['Items'][] = [
        'ProductName' => $row['ProductName'],
        'ImageURL' => $row['ImageURL'],
        'Quantity' => $row['Quantity']
    ];
}
?>

<style>
body {
    background: url('assets/images/background.jpg') no-repeat center center fixed;
    background-size: cover;
    font-family: 'Poppins', sans-serif;
}
.container {
    max-width: 1000px;
}
.order-card {
    background: rgba(255,255,255,0.9);
    border-radius: 15px;
    padding: 25px;
    margin-bottom: 30px;
    box-shadow: 0 6px 20px rgba(128, 0, 128, 0.2);
}
.order-header {
    border-bottom: 1px solid #eee;
    margin-bottom: 15px;
}
.order-header h5 {
    color: #c71585;
}
.product-list {
    display: flex;
    flex-wrap: wrap;
    gap: 15px;
}
.product-item {
    width: 130px;
    text-align: center;
}
.product-item img {
    height: 90px;
    object-fit: contain;
    border-radius: 8px;
    background: #fff;
    padding: 6px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.05);
}
.track-btn {
    background: linear-gradient(45deg, #ff69b4, #c71585);
    border: none;
    color: white;
    font-weight: bold;
    padding: 8px 20px;
    border-radius: 8px;
    float: right;
    transition: 0.3s;
}
.track-btn:hover {
    background: linear-gradient(45deg, #c71585, #ff69b4);
}
</style>

<div class="container my-5">
    <h2 class="text-center mb-4" style="color:#c71585;">📋 My Orders</h2>

    <?php if (empty($orders)): ?>
        <p class="text-center text-danger">No orders found.</p>
    <?php else: ?>
        <?php foreach ($orders as $id => $order): ?>
            <div class="order-card">
                <div class="order-header d-flex justify-content-between align-items-center">
                    <div>
                        <h5>Order #<?= $id ?></h5>
                        <p><strong>Status:</strong> <?= $order['Status'] ?> | 
                           <strong>Date:</strong> <?= $order['OrderDate']->format('Y-m-d H:i') ?></p>
                        <p><strong>Payment:</strong> <?= $order['PaymentMethod'] ?> |
                           <strong>Address:</strong> <?= htmlspecialchars($order['DeliveryAddress']) ?></p>
                    </div>
                    <a href="track_order.php?order_id=<?= $id ?>" class="track-btn">Track Order</a>
                </div>

                <div class="product-list">
                    <?php foreach ($order['Items'] as $item): ?>
                        <div class="product-item">
                            <img src="<?= $item['ImageURL'] ?>" alt="<?= $item['ProductName'] ?>">
                            <small><?= htmlspecialchars($item['ProductName']) ?></small><br>
                            <span class="badge bg-secondary">x<?= $item['Quantity'] ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<?php include('includes/footer.php'); ?>
