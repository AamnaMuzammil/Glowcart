<?php
$serverName = "DESKTOP-PGMN1LC\\SQLEXPRESS";
$connectionOptions = array("Database" => "GlowCartDB");
$conn = sqlsrv_connect($serverName, $connectionOptions);

if (!$conn) {
    die("Connection failed: " . print_r(sqlsrv_errors(), true));
}
?>
