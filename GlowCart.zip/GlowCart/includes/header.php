<?php // includes/header.php ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>GlowCart - All in One Beauty</title>

  <!-- Bootstrap & Fonts -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Great+Vibes&family=Playfair+Display:wght@600&family=Poppins:wght@400;500&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" defer></script>


  <style>
    body {
      background-color: #fff0f6;
      font-family: 'Poppins', sans-serif;
    }

    /* 🔥 Your Original Bold Navbar Gradient Preserved */
    .navbar {
      background: linear-gradient(90deg, #8b008b, #c71585, #ff1493);
      box-shadow: 0 4px 20px rgba(139, 0, 139, 0.3);
      padding: 0.6rem 1rem;
    }

    .navbar-brand {
      font-family: 'Great Vibes', cursive;
      font-size: 32px;
      color: #fff;
      display: flex;
      align-items: center;
      text-shadow: 1px 1px 4px rgba(255, 255, 255, 0.4);
    }

    .navbar-brand img {
      height: 40px;
      margin-right: 10px;
      border-radius: 50%;
      box-shadow: 0 0 10px rgba(255, 20, 147, 0.8);
    }

    .navbar-nav .nav-link {
      color: white !important;
      font-weight: 500;
      font-size: 15px;
      font-family: 'Playfair Display', serif;
      margin-left: 10px;
      transition: all 0.3s ease;
    }

    .navbar-nav .nav-link:hover {
      color: #ffd1dc !important;
    }

    .dropdown-menu {
      background-color: #fff0f6;
      border: none;
      border-radius: 10px;
      box-shadow: 0 8px 24px rgba(0,0,0,0.05);
    }

    .dropdown-menu .dropdown-item {
      font-weight: 500;
      color: #6a0572;
      padding: 10px 20px;
    }

    .dropdown-menu .dropdown-item:hover {
      background-color: #ffe6f0;
      color: #c71585;
    }

    .navbar-toggler {
      border: none;
    }

    .navbar-toggler-icon {
      background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 30 30' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath stroke='rgba(255,255,255,0.8)' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3E%3C/svg%3E");

    }
  </style>
</head>
<body>
    


<!-- ✅ Navbar -->
<nav class="navbar navbar-expand-lg">
  <div class="container">
    <a class="navbar-brand" href="index.php">
      <img src="assets/images/plainlogo.png" alt="GlowCart Logo">
      GlowCart
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">

        <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>

        <!-- 🔽 Dropdown fixed -->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="productsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Personalized Picks
          </a>
          <ul class="dropdown-menu" aria-labelledby="productsDropdown">
            <li><a class="dropdown-item" href="skincare.php">Skincare</a></li>
            <li><a class="dropdown-item" href="haircare.php">Haircare</a></li>
            <li><a class="dropdown-item" href="makeup.php">Makeup</a></li>
          </ul>
        </li>

        <li class="nav-item"><a class="nav-link" href="cart.php">My Cart</a></li>
        <li class="nav-item"><a class="nav-link" href="dashboard.php">My Profile</a></li>
     <!-- <?php
    // if (isset($_SESSION['user_id'])) {
    //     $userID = $_SESSION['user_id'];
    //     $trackQuery = "SELECT TOP 1 OrderID FROM Orders WHERE UserID = ? ORDER BY OrderDate DESC";
    //     $trackStmt = sqlsrv_query($conn, $trackQuery, array($userID));
    //     if ($row = sqlsrv_fetch_array($trackStmt, SQLSRV_FETCH_ASSOC)) {
    //         $latestOrderID = $row['OrderID'];
    //         echo '<li class="nav-item"><a class="nav-link" href="track_order.php?order_id=' . $latestOrderID . '">Track My Order</a></li>';
    //     }
    // }
    ?> -->
    <li class="nav-item"><a class="nav-link" href="my_orders.php">My Orders</a></li>

        <li class="nav-item"><a class="nav-link" href="login.php">Login</a></li>
        <li class="nav-item"><a class="nav-link" href="register.php">Sign Up</a></li>
        <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
        

      </ul>

      </ul>
    </div>
  </div>
</nav>

<!-- ✅ Bootstrap Script (Required for dropdown) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
