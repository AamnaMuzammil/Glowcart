<?php
// includes/footer.php
?>
<!-- Modern Animated Footer -->
<footer class="footer text-center text-white pt-4" style="background: linear-gradient(to right, #ff6ec4, #7873f5); font-family: 'Poppins', sans-serif;">
    <div class="container">
        <h4 class="mb-3">Follow Us</h4>
        <div class="social-icons d-flex justify-content-center gap-4 mb-4">
            <a href="https://www.instagram.com/" target="_blank" class="social-link instagram"><i class="fab fa-instagram"></i></a>
            <a href="https://www.facebook.com/" target="_blank" class="social-link facebook"><i class="fab fa-facebook-f"></i></a>
            <a href="https://www.google.com/" target="_blank" class="social-link google"><i class="fab fa-google"></i></a>
        </div>

        <p class="mb-1">&copy; 2025 <strong>GlowCart</strong>. All Rights Reserved.</p>
        <p class="mb-0">Designed with ❤️ by GlowCart Team</p>
    </div>

    <style>
        .social-icons .social-link {
            display: flex;
            justify-content: center;
            align-items: center;
            background: white;
            color: #ff69b4;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            font-size: 20px;
            transition: all 0.3s ease-in-out;
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        }

        .social-icons .social-link:hover {
            transform: scale(1.2) rotate(10deg);
            color: white;
        }

        .social-link.instagram:hover {
            background: #E1306C;
        }

        .social-link.facebook:hover {
            background: #3b5998;
        }

        .social-link.google:hover {
            background: #db4437;
        }

        .footer {
            animation: fadeInUp 1s ease-in-out;
        }

        @keyframes fadeInUp {
            0% {
                opacity: 0;
                transform: translateY(40px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>

    <!-- Font Awesome for social icons -->
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</footer>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<!-- Your custom JS (if needed) -->
<script src="assets/js/script.js"></script>
</body>
</html>
