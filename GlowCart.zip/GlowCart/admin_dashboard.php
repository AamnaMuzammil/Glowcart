<?php
include('includes/db.php');
session_start();

if (!isset($_SESSION['admin'])) {
    header('Location: admin_login.php');
    exit();
}
include('includes/header.php');
?>

<style>
    body {
        background: url('assets/images/background.jpg') no-repeat center center fixed;
        background-size: cover;
        font-family: 'Poppins', sans-serif;
        min-height: 100vh;
        display: flex;
        flex-direction: column;
    }

    .main-content {
        flex: 1;
        padding-top: 100px;
    }

    .dashboard-title {
        font-family: 'Playfair Display', serif;
        color: #c71585;
        text-align: center;
        margin-bottom: 30px;
        font-size: 36px;
        animation: fadeIn 1s ease;
    }

    .card-box {
        background: rgba(255, 255, 255, 0.95);
        border-radius: 15px;
        padding: 25px;
        text-align: center;
        box-shadow: 0 10px 30px rgba(199, 21, 133, 0.2);
        transition: transform 0.3s;
    }

    .card-box:hover {
        transform: translateY(-5px);
    }

    .card-box h4 {
        color: #8b008b;
        font-size: 22px;
        margin-top: 10px;
    }

    .dashboard-buttons .btn {
        background: linear-gradient(45deg, #ff69b4, #c71585);
        border: none;
        color: white;
        font-weight: bold;
        padding: 12px 25px;
        border-radius: 10px;
        transition: 0.3s;
        font-size: 16px;
    }

    .dashboard-buttons .btn:hover {
        background: linear-gradient(45deg, #c71585, #ff69b4);
        transform: scale(1.05);
    }

    footer {
        background: rgba(255, 255, 255, 0.85);
        color: #555;
        text-align: center;
        padding: 15px;
        margin-top: auto;
        border-top: 1px solid #eee;
    }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(-20px); }
        to { opacity: 1; transform: translateY(0); }
    }
</style>

<div class="container main-content">
    <h2 class="dashboard-title">✨ Admin Dashboard</h2>

    <div class="row g-4">
        <div class="col-md-6">
            <div class="card-box">
                <i class="fas fa-plus-circle fa-2x text-pink"></i>
                <h4><a href="add_product.php" class="btn w-100 mt-3">Add Product</a></h4>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card-box">
                <i class="fas fa-shopping-bag fa-2x text-pink"></i>
                <h4><a href="view_orders.php" class="btn w-100 mt-3">View Orders</a></h4>
            </div>
        </div>

         <div class="col-md-6">
    <div class="card-box">
        <i class="fas fa-chart-line fa-2x text-pink"></i>
        <h4><a href="admin_graph.php" class="btn w-100 mt-3">View Graphs</a></h4>
    </div>
</div>

        <div class="col-md-6">
            <div class="card-box">
                <i class="fas fa-boxes fa-2x text-pink"></i>
                <h4><a href="manage_stock.php" class="btn w-100 mt-3">Manage Stock</a></h4>
            </div>
        </div>
    </div>
</div>
 
<?php include('includes/footer.php'); ?>
