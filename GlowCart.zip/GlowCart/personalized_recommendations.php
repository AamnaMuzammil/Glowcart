<?php
session_start();
include('includes/db.php');
include('includes/header.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$userID = $_SESSION['user_id'];

// Fetch user preferences
$sqlPref = "SELECT SkinType, SkinTone, HairType FROM Users WHERE UserID = ?";
$stmtPref = sqlsrv_query($conn, $sqlPref, array($userID));
$userPref = sqlsrv_fetch_array($stmtPref, SQLSRV_FETCH_ASSOC);

if (!$userPref) {
    echo "<div class='container text-danger mt-5'>Preferences not found. Please update your profile.</div>";
    exit();
}

$skinType = $userPref['SkinType'];
$skinTone = $userPref['SkinTone'];
$hairType = $userPref['HairType'];

// Fetch matching skincare products
$sqlSkincare = "SELECT * FROM Products WHERE Category = 'Skincare' AND (SkinType = ? OR SkinTone = ?)";
$skincare = sqlsrv_query($conn, $sqlSkincare, array($skinType, $skinTone));

// Fetch matching haircare products
$sqlHaircare = "SELECT * FROM Products WHERE Category = 'Haircare' AND HairType = ?";
$haircare = sqlsrv_query($conn, $sqlHaircare, array($hairType));

// Fetch matching makeup products
$sqlMakeup = "SELECT * FROM Products WHERE Category = 'Makeup' AND (SkinTone = ? OR SkinType = ?)";
$makeup = sqlsrv_query($conn, $sqlMakeup, array($skinTone, $skinType));
?>

<!DOCTYPE html>
<html>
<head>
    <title>Recommended for You - GlowCart</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            background: url('assets/images/background.jpg') no-repeat center center fixed;
            background-size: cover;
            font-family: 'Segoe UI', sans-serif;
        }
        .section-title {
            color: #d63384;
            margin-top: 40px;
        }
        .card {
            background: rgba(255,255,255,0.8);
            border-radius: 15px;
            padding: 10px;
            transition: 0.3s ease;
        }
        .card:hover {
            transform: scale(1.03);
            box-shadow: 0 8px 25px rgba(255, 105, 180, 0.4);
        }
    </style>
</head>
<body>

<div class="container py-5">
    <h2 class="text-center text-white mb-5">✨ Products Picked Just for You ✨</h2>

    <h4 class="section-title">💆 Skincare for <?php echo $skinType; ?> / <?php echo $skinTone; ?></h4>
    <div class="row">
        <?php while ($row = sqlsrv_fetch_array($skincare, SQLSRV_FETCH_ASSOC)): ?>
            <div class="col-md-4 mb-3">
                <div class="card">
                    <img src="<?php echo $row['ImageURL']; ?>" class="card-img-top" style="height: 200px; object-fit: cover;">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $row['ProductName']; ?></h5>
                        <p class="card-text">Rs. <?php echo number_format($row['Price'], 2); ?></p>
                        <form method="POST" action="add_to_cart.php">
                            <input type="hidden" name="product_id" value="<?php echo $row['ProductID']; ?>">
                            <button class="btn btn-sm btn-pink">Add to Cart</button>
                        </form>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    </div>

    <h4 class="section-title">💇 Haircare for <?php echo $hairType; ?></h4>
    <div class="row">
        <?php while ($row = sqlsrv_fetch_array($haircare, SQLSRV_FETCH_ASSOC)): ?>
            <div class="col-md-4 mb-3">
                <div class="card">
                    <img src="<?php echo $row['ImageURL']; ?>" class="card-img-top" style="height: 200px; object-fit: cover;">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $row['ProductName']; ?></h5>
                        <p class="card-text">Rs. <?php echo number_format($row['Price'], 2); ?></p>
                        <form method="POST" action="add_to_cart.php">
                            <input type="hidden" name="product_id" value="<?php echo $row['ProductID']; ?>">
                            <button class="btn btn-sm btn-pink">Add to Cart</button>
                        </form>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    </div>

    <h4 class="section-title">💄 Makeup for <?php echo $skinTone; ?> / <?php echo $skinType; ?></h4>
    <div class="row">
        <?php while ($row = sqlsrv_fetch_array($makeup, SQLSRV_FETCH_ASSOC)): ?>
            <div class="col-md-4 mb-3">
                <div class="card">
                    <img src="<?php echo $row['ImageURL']; ?>" class="card-img-top" style="height: 200px; object-fit: cover;">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $row['ProductName']; ?></h5>
                        <p class="card-text">Rs. <?php echo number_format($row['Price'], 2); ?></p>
                        <form method="POST" action="add_to_cart.php">
                            <input type="hidden" name="product_id" value="<?php echo $row['ProductID']; ?>">
                            <button class="btn btn-sm btn-pink">Add to Cart</button>
                        </form>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
</div>

</body>
</html>
