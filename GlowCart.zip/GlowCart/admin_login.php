<?php 
session_start();
$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Hardcoded admin credentials - change as needed
    if ($username === 'amna' && $password === 'amna123') {
        $_SESSION['admin'] = $username;  // Mark admin as logged in
        header('Location: manage_stock.php'); // Redirect to manage stock
        exit();
    } else {
        $message = "Invalid admin credentials.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Admin Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <style>
        body {
            background: url('assets/images/background.jpg') no-repeat center center fixed;
            background-size: cover;
            font-family: 'Segoe UI', sans-serif;
            animation: fadeInBody 2s ease-in;
        }

        h2 {
            color: #c71585;
            font-family: 'Caveat', cursive;
            animation: slideInTop 1.5s ease-out;
        }

        .card {
            animation: zoomIn 1.2s ease;
            background: rgba(255, 255, 255, 0.9);
            border: none;
            border-radius: 15px;
        }

        .btn-custom {
            background-color: #c71585;
            color: white;
            transition: transform 0.3s ease, background-color 0.3s ease;
        }

        .btn-custom:hover {
            transform: scale(1.05);
            background-color: #a0136e;
        }

        @keyframes fadeInBody {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes zoomIn {
            0% { transform: scale(0.8); opacity: 0; }
            100% { transform: scale(1); opacity: 1; }
        }

        @keyframes slideInTop {
            0% { transform: translateY(-50px); opacity: 0; }
            100% { transform: translateY(0); opacity: 1; }
        }
    </style>
</head>
<body>
<div class="container mt-5">
    <h2 class="text-center mb-4">Admin Login</h2>
    <div class="card p-4 shadow-lg mx-auto" style="max-width: 400px;">
        <?php if ($message): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>
        <form method="POST" action="admin_login.php">
            <div class="mb-3">
                <label for="username" class="form-label">Username</label>
                <input type="text" id="username" name="username" class="form-control" required />
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" id="password" name="password" class="form-control" required />
            </div>
            <button type="submit" class="btn btn-custom w-100">Login</button>
        </form>
    </div>
</div>
</body>
</html>
