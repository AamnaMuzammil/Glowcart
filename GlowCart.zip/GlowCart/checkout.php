<?php
session_start();
include('includes/db.php');

// PHPMailer include karo
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../vendor/autoload.php';
// Agar composer use kiya hai
// Agar manually include kiya hai to:
// require 'includes/PHPMailer/src/Exception.php';
// require 'includes/PHPMailer/src/PHPMailer.php';
// require 'includes/PHPMailer/src/SMTP.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$stock_error = null;
$cart_items = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $order_date = date('Y-m-d H:i:s');
    $address = $_POST['address'];
    $payment_method = $_POST['payment_method'];

    // ✅ Fetch cart items
    $sql = "SELECT c.ProductID, c.Quantity, p.Price FROM carttwo c 
            JOIN Products p ON c.ProductID = p.ProductID
            WHERE c.UserID = ?";
    $params = array($user_id);
    $result = sqlsrv_query($conn, $sql, $params);

    while ($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
        $product_id = $row['ProductID'];
        $quantity = $row['Quantity'];
        $price = $row['Price'];
        $total = $price * $quantity;

        // ✅ Check stock
        $check_stock_sql = "SELECT QuantityInStock FROM Products WHERE ProductID = ?";
        $stock_stmt = sqlsrv_query($conn, $check_stock_sql, array($product_id));
        $stock_row = sqlsrv_fetch_array($stock_stmt, SQLSRV_FETCH_ASSOC);

        if ($stock_row === false || $stock_row['QuantityInStock'] < $quantity) {
            $stock_error = "❌ Sorry! One or more items in your cart have insufficient stock. Please update your cart.";
            break;
        }

        // ✅ Store item for later insertion
        $cart_items[] = [
            'product_id' => $product_id,
            'quantity' => $quantity,
            'price' => $price,
            'total' => $total
        ];
    }

    // ✅ If no stock error and items exist
    if (!$stock_error && count($cart_items) > 0) {
        // Insert into Orders table
        $insert_order_sql = "INSERT INTO Orders (UserID, OrderDate, DeliveryAddress, PaymentMethod) VALUES (?, ?, ?, ?)";
        $insert_order_params = array($user_id, $order_date, $address, $payment_method);
        $insert_order_result = sqlsrv_query($conn, $insert_order_sql, $insert_order_params);

        if (!$insert_order_result) {
            die(print_r(sqlsrv_errors(), true));
        }

        // Get Order ID
        $fetch_order_id = sqlsrv_query($conn, "SELECT @@IDENTITY AS OrderID");
        $row = sqlsrv_fetch_array($fetch_order_id, SQLSRV_FETCH_ASSOC);
        $order_id = $row['OrderID'];

        // Insert each item
        foreach ($cart_items as $item) {
            $insert_item_sql = "INSERT INTO OrderItems (OrderID, ProductID, Quantity, TotalPrice) VALUES (?, ?, ?, ?)";
            $insert_item_params = array($order_id, $item['product_id'], $item['quantity'], $item['total']);
            sqlsrv_query($conn, $insert_item_sql, $insert_item_params);
        }

        // Clear cart
        sqlsrv_query($conn, "DELETE FROM carttwo WHERE UserID = ?", array($user_id));

        // ✅ SEND EMAIL
        $mail = new PHPMailer(true);
        try {
            //Server settings
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'm.uzairkhan241@gmail.com'; 
            $mail->Password = 'xqsz igan ajvy uvsr'; 
            $mail->SMTPSecure = 'tls';
            $mail->Port = 587;

            //Recipients
            $mail->setFrom('m.uzairkhan241@gmail.com', 'GlowCart');
           // Replace hardcoded email with actual user's email
$user_email_sql = "SELECT Email FROM Users WHERE UserID = ?";
$user_stmt = sqlsrv_query($conn, $user_email_sql, array($user_id));
$user_row = sqlsrv_fetch_array($user_stmt, SQLSRV_FETCH_ASSOC);
$user_email = $user_row['Email'];

$mail->addAddress($user_email, 'Valued Customer');


            // Content
            $mail->isHTML(true);
            $mail->Subject = 'New Order Placed';
            $mail->Body = "Order ID: {$order_id}<br>Customer ID: {$user_id}<br>Address: {$address}<br>Payment Method: {$payment_method}
             <p>Thanks for shopping with <strong>GlowCart</strong> 💖</p>";

            $mail->send();
            // echo 'Message has been sent';
        } catch (Exception $e) {
            error_log("Email could not be sent. Mailer Error: {$mail->ErrorInfo}");
        }

        // Redirect to receipt
        header("Location: receipt.php");
        exit();
    }
}
?>


<!-- HTML BELOW -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>GlowCart - Checkout</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: url('assets/images/background.jpg') no-repeat center center fixed;
            background-size: cover;
            font-family: 'Poppins', sans-serif;
        }
        .checkout-container {
            display: flex;
            justify-content: center;
            padding: 60px 20px;
        }
        .card {
            background: rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
            padding: 30px;
            max-width: 500px;
            width: 100%;
        }
        .form-label {
            color: #c71585;
            font-weight: bold;
        }
        .form-control {
            border: 2px solid #ff69b4;
            border-radius: 10px;
        }
        .btn {
            background: #ff69b4;
            color: white;
            font-weight: bold;
        }
        .btn:hover {
            background: #c71585;
        }
    </style>
</head>
<body>

<?php include('includes/header.php'); ?>

<div class="checkout-container">
    <div class="card">
        <h2 class="text-center mb-4" style="color:#c71585;">Checkout</h2>

        <?php if (!empty($stock_error)): ?>
            <div class="alert alert-danger text-center" role="alert">
                <?= $stock_error ?>
            </div>
        <?php endif; ?>

        <form method="POST">
            <div class="mb-3">
                <label class="form-label">Delivery Address</label>
                <textarea name="address" class="form-control" required></textarea>
            </div>
            <div class="mb-3">
                <label class="form-label">Payment Method</label>
                <select name="payment_method" class="form-control" required>
                    <option value="Cash on Delivery">Cash on Delivery</option>
                    <option value="Credit/Debit Card">Credit/Debit Card</option>
                </select>
            </div>
            <button type="submit" class="btn w-100">Place Order</button>
        </form>
    </div>
</div>

<?php include('includes/footer.php'); ?>

</body>
</html>