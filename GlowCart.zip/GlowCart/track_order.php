<?php
session_start();
include('includes/db.php');
include('includes/header.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['order_id'])) {
    echo "<div class='container mt-5 text-danger text-center'>No order selected to track.</div>";
    exit();
}

$orderID = intval($_GET['order_id']);
$userID = $_SESSION['user_id'];

$sql = "SELECT * FROM Orders WHERE OrderID = ? AND UserID = ?";
$params = array($orderID, $userID);
$stmt = sqlsrv_query($conn, $sql, $params);

if (!$stmt || !sqlsrv_has_rows($stmt)) {
    echo "<div class='container mt-5 text-danger text-center'>Order not found or you do not have permission to view this order.</div>";
    exit();
}

$order = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
$status = $order['Status'];
$orderDate = $order['OrderDate']->format('Y-m-d H:i');
$delivery = $order['DeliveryAddress'];
$payment = $order['PaymentMethod'];
?>

<!-- 🎨 CSS -->
<style>
body {
    background: url('assets/images/background.jpg') no-repeat center center fixed;
    background-size: cover;
    font-family: 'Poppins', sans-serif;
   
}


.container {
    max-width: 960px;
    margin: auto;
    padding: 0 20px;
}


.status-card {
    background: rgba(255, 255, 255, 0.8);
    border-radius: 20px;
    padding: 40px;
    box-shadow: 0 10px 30px rgba(199, 21, 133, 0.15);
    backdrop-filter: blur(10px);
}

.status-title {
    color: #c71585;
    font-family: 'Playfair Display', serif;
    font-size: 32px;
    text-align: center;
    margin-bottom: 30px;
}

.summary {
    background-color: #fff0f6;
    border-left: 5px solid #ff69b4;
    padding: 15px 25px;
    border-radius: 12px;
    margin-bottom: 30px;
    font-size: 15px;
}

.tracker {
    display: flex;
    justify-content: space-between;
    align-items: center;
    position: relative;
    margin-top: 40px;
}

.tracker::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 0;
    right: 0;
    height: 6px;
    background: #ffe4f2;
    z-index: 0;
    transform: translateY(-50%);
    border-radius: 5px;
}

.step {
    position: relative;
    z-index: 1;
    text-align: center;
    width: 33.33%;
}

.step .circle {
    width: 36px;
    height: 36px;
    background-color: #ddd;
    border-radius: 50%;
    margin: auto;
    line-height: 36px;
    font-weight: bold;
    color: white;
    margin-bottom: 8px;
}

.step.active .circle {
    background-color: #c71585;
    box-shadow: 0 0 10px rgba(255, 105, 180, 0.6);
}

.step p {
    font-size: 14px;
    color: #333;
}

.alert-status {
    font-weight: 500;
    text-align: center;
    font-size: 16px;
}
</style>

<!-- ✅ TRACKING UI -->
<div class="container my-5">
    <div class="status-card">
        <h2 class="status-title">🛍️ Track Your Order</h2>

        <div class="summary">
            <p><strong>Order ID:</strong> #<?= $orderID ?></p>
            <p><strong>Order Date:</strong> <?= $orderDate ?></p>
            <p><strong>Payment Method:</strong> <?= htmlspecialchars($payment) ?></p>
            <p><strong>Delivery Address:</strong> <?= htmlspecialchars($delivery) ?></p>
            <p><strong>Current Status:</strong> <span style="color:#8b008b"><?= $status ?></span></p>
        </div>

        <!-- 🎯 Progress Bar -->
        <div class="tracker">
            <div class="step <?= in_array($status, ['Pending','Shipped','Delivered']) ? 'active' : '' ?>">
                <div class="circle">1</div>
                <p>Pending</p>
            </div>
            <div class="step <?= in_array($status, ['Shipped','Delivered']) ? 'active' : '' ?>">
                <div class="circle">2</div>
                <p>Shipped</p>
            </div>
            <div class="step <?= $status == 'Delivered' ? 'active' : '' ?>">
                <div class="circle">3</div>
                <p>Delivered</p>
            </div>
        </div>

        <!-- 💬 Status Message -->
        <div class="mt-4 alert-status">
            <?php if ($status == 'Delivered') { ?>
                <div class="alert alert-success">
                    🎉 Your order has been <strong>delivered</strong>. We hope you love your products!
                </div>
            <?php } elseif ($status == 'Shipped') { ?>
                <div class="alert alert-info">
                    🚚 Your order is <strong>on the way</strong> and will arrive within 1–2 days.
                </div>
            <?php } elseif ($status == 'Pending') { ?>
                <div class="alert alert-warning">
                    🕓 Your order is <strong>being prepared</strong>. Estimated delivery in 3–5 business days.
                </div>
            <?php } else { ?>
                <div class="alert alert-secondary">
                    📋 Status: <?= htmlspecialchars($status) ?>
                </div>
            <?php } ?>
        </div>
    </div>
</div>
