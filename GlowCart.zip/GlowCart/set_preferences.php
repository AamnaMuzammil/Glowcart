<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['UserID'])) {
    header("Location: login.php");
    exit();
}

// SQL Server connection
$serverName = "localhost";
$connectionOptions = [
    "Database" => "GlowCartDB",
    "UID" => "", // Leave blank for Windows Authentication
    "PWD" => ""  // Leave blank for Windows Authentication
];
$conn = sqlsrv_connect($serverName, $connectionOptions);

if (!$conn) {
    die(print_r(sqlsrv_errors(), true));
}

$userID = $_SESSION['UserID'];

// Fetch user details
$userQuery = "SELECT * FROM Users WHERE UserID = ?";
$userParams = array($userID);
$userStmt = sqlsrv_query($conn, $userQuery, $userParams);
$userRow = sqlsrv_fetch_array($userStmt, SQLSRV_FETCH_ASSOC);

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $skinType = $_POST['skin_type'];
    $skinTone = $_POST['skin_tone'];
    $hairType = $_POST['hair_type'];

    $checkQuery = "SELECT * FROM UserPreferences WHERE UserID = ?";
    $checkParams = array($userID);
    $checkStmt = sqlsrv_query($conn, $checkQuery, $checkParams);

    if (sqlsrv_has_rows($checkStmt)) {
        $updateQuery = "UPDATE UserPreferences SET SkinType = ?, SkinTone = ?, HairType = ? WHERE UserID = ?";
        $updateParams = array($skinType, $skinTone, $hairType, $userID);
        sqlsrv_query($conn, $updateQuery, $updateParams);
    } else {
        $insertQuery = "INSERT INTO UserPreferences (UserID, SkinType, SkinTone, HairType) VALUES (?, ?, ?, ?)";
        $insertParams = array($userID, $skinType, $skinTone, $hairType);
        sqlsrv_query($conn, $insertQuery, $insertParams);
    }

    // Redirect to personalized recommendations page
    header("Location: personalized_recommendations.php");
    exit();
}

// Fetch existing preferences
$prefQuery = "SELECT * FROM UserPreferences WHERE UserID = ?";
$prefStmt = sqlsrv_query($conn, $prefQuery, array($userID));
$prefRow = sqlsrv_fetch_array($prefStmt, SQLSRV_FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Dashboard | GlowCart</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            margin: 0;
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #f5d1e3, #e6b8e7);
        }
        nav {
            background: #8e44ad;
            padding: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: white;
        }
        nav h1 {
            font-size: 1.5rem;
            margin: 0;
        }
        nav a {
            color: white;
            text-decoration: none;
            padding: 8px 12px;
            background: #c75ab7;
            border-radius: 5px;
            transition: 0.3s;
        }
        nav a:hover {
            background: #a942a2;
        }
        .container {
            display: flex;
            justify-content: center;
            align-items: flex-start;
            padding: 40px;
        }
        .card {
            background: rgba(255,255,255,0.9);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.2);
            width: 400px;
            margin: 20px;
        }
        .card h2 {
            text-align: center;
            color: #c75ab7;
        }
        label {
            display: block;
            margin-top: 10px;
            color: #7e3c8e;
        }
        select, button {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            border-radius: 5px;
            border: 1px solid #ddd;
        }
        button {
            background: #c75ab7;
            color: white;
            border: none;
            cursor: pointer;
            margin-top: 15px;
        }
        button:hover {
            background: #a942a2;
        }
    </style>
</head>
<body>

<nav>
    <h1>Welcome, <?php echo htmlspecialchars($userRow['FullName']); ?>!</h1>
    <a href="logout.php">Logout</a>
</nav>

<div class="container">
    <div class="card">
        <h2>Your Details</h2>
        <p><strong>Email:</strong> <?php echo htmlspecialchars($userRow['Email']); ?></p>
        <p><strong>Username:</strong> <?php echo htmlspecialchars($userRow['Username']); ?></p>
        <p><strong>UserID:</strong> <?php echo $userID; ?></p>
    </div>

    <div class="card">
        <h2>Your Preferences</h2>
        <form method="POST">
            <label for="skin_type">Skin Type:</label>
            <select name="skin_type" id="skin_type" required>
                <option value="">Select Skin Type</option>
                <option value="Oily" <?php if ($prefRow && $prefRow['SkinType']=='Oily') echo 'selected'; ?>>Oily</option>
                <option value="Dry" <?php if ($prefRow && $prefRow['SkinType']=='Dry') echo 'selected'; ?>>Dry</option>
                <option value="Combination" <?php if ($prefRow && $prefRow['SkinType']=='Combination') echo 'selected'; ?>>Combination</option>
                
            </select>

            <label for="skin_tone">Skin Tone:</label>
            <select name="skin_tone" id="skin_tone" required>
                <option value="">Select Skin Tone</option>
                <option value="Fair" <?php if ($prefRow && $prefRow['SkinTone']=='Fair') echo 'selected'; ?>>Fair</option>
                <option value="Medium" <?php if ($prefRow && $prefRow['SkinTone']=='Medium') echo 'selected'; ?>>Medium</option>
                <option value="Dark" <?php if ($prefRow && $prefRow['SkinTone']=='Dark') echo 'selected'; ?>>Dark</option>
            </select>

            <label for="hair_type">Hair Type:</label>
            <select name="hair_type" id="hair_type" required>
                <option value="">Select Hair Type</option>
                <option value="Straight" <?php if ($prefRow && $prefRow['HairType']=='Straight') echo 'selected'; ?>>Straight</option>
                <option value="Wavy" <?php if ($prefRow && $prefRow['HairType']=='Wavy') echo 'selected'; ?>>Wavy</option>
                <option value="Curly" <?php if ($prefRow && $prefRow['HairType']=='Curly') echo 'selected'; ?>>Curly</option>
                
            </select>

            <button type="submit">Save Preferences</button>
        </form>
    </div>
</div>

</body>
</html>
